# KONI Klaten Patch 14.2

Perbaikan test validasi pada DemoExperienceTest menggunakan `withViewErrors()` dan satu request.

Lihat PATCH-14.2-INSTRUKSI.md untuk pemasangan.
