<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Portal informasi KONI Kabupaten Klaten: cabang olahraga, atlet, pelatih, dan kepengurusan.">
    <title>@yield('title', 'Portal Informasi') - KONI Kabupaten Klaten</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="min-h-screen bg-[#F7F8FA] text-slate-900 antialiased">
    <header class="sticky top-0 z-40 border-b border-slate-200/80 bg-white/95 backdrop-blur">
        <div class="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
            <a href="{{ route('public.home') }}" class="flex shrink-0 items-center gap-3" aria-label="Beranda KONI Klaten">
                @if(file_exists(public_path('images/logo-koni.png')))
                    <img src="{{ asset('images/logo-koni.png') }}" alt="Logo KONI" class="h-11 w-11 rounded-xl bg-white object-contain">
                @else
                    <span class="flex h-11 w-11 items-center justify-center rounded-xl bg-[#D71920] text-lg font-black text-white shadow-sm">K</span>
                @endif
                <span class="leading-tight">
                    <span class="block text-sm font-black tracking-wide text-slate-950">KONI KLATEN</span>
                    <span class="block text-[10px] font-semibold tracking-[0.16em] text-slate-500">KABUPATEN KLATEN</span>
                </span>
            </a>

            <nav class="hidden items-center gap-7 text-sm font-semibold text-slate-600 lg:flex">
                <a href="{{ route('public.home') }}" class="transition hover:text-[#D71920]">Beranda</a>
                <a href="{{ route('public.home') }}#tentang" class="transition hover:text-[#D71920]">Profil KONI</a>
                <a href="{{ route('public.cabor.index') }}" class="transition hover:text-[#D71920]">Cabang Olahraga</a>
                <a href="{{ route('public.struktur.index') }}" class="transition hover:text-[#D71920]">Struktur Pengurus</a>
            </nav>

            <div class="flex items-center gap-2">
                @if(Route::has('login'))
                    <a href="{{ route('login') }}" class="rounded-xl bg-[#D71920] px-4 py-2.5 text-xs font-bold text-white shadow-sm transition hover:bg-[#B9151B] sm:text-sm">
                        Portal Anggota <span aria-hidden="true">→</span>
                    </a>
                @endif
                <details class="relative lg:hidden">
                    <summary class="cursor-pointer list-none rounded-xl border border-slate-200 px-3 py-2.5 text-sm font-bold text-slate-700">Menu</summary>
                    <nav class="absolute right-0 top-full mt-2 grid w-56 gap-1 rounded-2xl border border-slate-200 bg-white p-2 shadow-xl">
                        <a class="rounded-lg px-3 py-2 text-sm hover:bg-slate-50" href="{{ route('public.home') }}">Beranda</a>
                        <a class="rounded-lg px-3 py-2 text-sm hover:bg-slate-50" href="{{ route('public.home') }}#tentang">Profil KONI</a>
                        <a class="rounded-lg px-3 py-2 text-sm hover:bg-slate-50" href="{{ route('public.cabor.index') }}">Cabang Olahraga</a>
                        <a class="rounded-lg px-3 py-2 text-sm hover:bg-slate-50" href="{{ route('public.struktur.index') }}">Struktur Pengurus</a>
                    </nav>
                </details>
            </div>
        </div>
    </header>

    <main>
        @yield('content')
    </main>

    <footer class="mt-20 bg-[#17191F] text-white">
        <div class="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-2 lg:px-8">
            <div>
                <div class="flex items-center gap-3">
                    <span class="flex h-11 w-11 items-center justify-center rounded-xl bg-[#D71920] text-lg font-black">K</span>
                    <div>
                        <p class="font-black tracking-wide">KONI KABUPATEN KLATEN</p>
                        <p class="text-xs text-slate-400">Portal Informasi Olahraga</p>
                    </div>
                </div>
                <p class="mt-5 max-w-md text-sm leading-7 text-slate-400">Pusat informasi cabang olahraga, atlet, pelatih, dan kepengurusan Komite Olahraga Nasional Indonesia Kabupaten Klaten.</p>
            </div>
            <div class="md:justify-self-end">
                <p class="text-sm font-bold">Jelajahi</p>
                <div class="mt-4 grid gap-3 text-sm text-slate-400">
                    <a class="transition hover:text-white" href="{{ route('public.cabor.index') }}">Daftar Cabang Olahraga</a>
                    <a class="transition hover:text-white" href="{{ route('public.struktur.index') }}">Struktur Pengurus KONI</a>
                    @if(Route::has('login'))
                        <a class="transition hover:text-white" href="{{ route('login') }}">Login Portal Anggota</a>
                    @endif
                </div>
            </div>
        </div>
        <div class="border-t border-white/10">
            <div class="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-5 text-xs text-slate-500 sm:px-6 md:flex-row md:items-center md:justify-between lg:px-8">
                <span>© {{ date('Y') }} KONI Kabupaten Klaten.</span>
                <span>Portal Informasi dan Manajemen Olahraga</span>
            </div>
        </div>
    </footer>
</body>
</html>
