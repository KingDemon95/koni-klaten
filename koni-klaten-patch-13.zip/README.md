# KONI Klaten — Patch 13

Modul Laporan & Rekapitulasi untuk Admin KONI, Staff KONI, dan Admin Cabor.

Lihat `PATCH-13-INSTRUKSI.md` untuk pemasangan dan pengujian.
Tidak ada migration database pada patch ini.
