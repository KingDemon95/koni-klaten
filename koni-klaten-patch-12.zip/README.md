# Sistem Informasi dan Manajemen KONI Kabupaten Klaten

Aplikasi Laravel untuk portal informasi publik dan pengelolaan internal KONI Kabupaten Klaten.

## Modul aplikasi

- **Public:** profil KONI, cabang olahraga, struktur pengurus, agenda dan kejuaraan, berita, dokumentasi, serta statistik prestasi.
- **Admin KONI:** pengelolaan akun, data organisasi, agenda, persuratan, publikasi, profil organisasi, dan monitoring prestasi.
- **Staff KONI:** pengelolaan agenda dan publikasi serta perantara wajib dalam alur persuratan Admin Cabor ke Admin KONI.
- **Admin Cabor:** pengelolaan data cabang sendiri, agenda, persuratan, dan verifikasi prestasi atlet/pelatih dari cabangnya.
- **Atlet dan Pelatih:** pengelolaan biodata sendiri, pengajuan prestasi, izin latihan, serta unduh template surat.
- **Notifikasi:** pusat notifikasi internal untuk perubahan prestasi, izin latihan, agenda, dan alur persuratan; setiap pengguna hanya dapat melihat notifikasinya sendiri.

## Prasyarat pengembangan

- Docker Engine dan Docker Compose
- Ubuntu / WSL Ubuntu (direkomendasikan untuk alur pengembangan ini)
- PHP dan Composer tersedia di Ubuntu untuk pengelolaan dependency lokal bila diperlukan
- Node.js dan npm tersedia di Ubuntu bila asset perlu dibangun di luar container

## Menjalankan aplikasi

Dari root repository:

```bash
composer install
cp .env.example .env   # hanya jika .env belum ada; jangan menimpa .env yang sudah dipakai
php artisan key:generate # hanya untuk instalasi baru
```

Isi `.env` dengan koneksi Docker yang sesuai, kemudian:

```bash
docker compose up -d --build
docker compose exec laravel.test php artisan migrate
docker compose exec laravel.test php artisan db:seed
docker compose exec laravel.test npm install
docker compose exec laravel.test npm run build
docker compose exec laravel.test php artisan storage:link
```

Buka `APP_URL` yang ditentukan di `.env` (umumnya `http://localhost:8000`).

## Pemeriksaan sebelum perubahan kode

```bash
docker compose exec laravel.test php artisan test
docker compose exec laravel.test php artisan route:list
```

Database pengujian dikonfigurasi terpisah menggunakan SQLite in-memory di `phpunit.xml`. Jangan menjalankan `migrate:fresh` pada database kerja yang berisi data proyek.

## Waktu aplikasi

Zona waktu default aplikasi adalah `Asia/Jakarta`. Jika `.env` sudah memiliki `APP_TIMEZONE`, pastikan nilainya `Asia/Jakarta` agar tanggal agenda dan publikasi mengikuti waktu Indonesia Barat.

## Endpoint operasional dan SEO

- `/up` — health check bawaan Laravel.
- `/sitemap.xml` — sitemap untuk halaman publik, cabor aktif, agenda terbit, berita terbit, dan dokumentasi terbit.
- `/robots.txt` — mengizinkan crawling halaman publik dan mengecualikan panel login/manajemen.

## Deployment

Ikuti [Panduan Deployment](docs/DEPLOYMENT.md) sebelum aplikasi dipasang pada server produksi. Jangan menggunakan konfigurasi `.env` development untuk produksi.
