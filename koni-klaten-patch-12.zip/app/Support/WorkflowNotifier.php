<?php

namespace App\Support;

use App\Models\User;
use App\Notifications\WorkflowNotification;

class WorkflowNotifier
{
    public static function toUser(
        ?User $user,
        string $title,
        string $message,
        string $url,
        string $category = 'info',
        ?int $exceptUserId = null,
    ): void {
        if (! $user || ! $user->is_active || $user->id === $exceptUserId) {
            return;
        }

        $user->notify(new WorkflowNotification($title, $message, $url, $category));
    }

    public static function toRole(
        string $role,
        string $title,
        string $message,
        string $url,
        string $category = 'info',
        ?int $caborId = null,
        ?int $exceptUserId = null,
    ): void {
        $users = User::query()
            ->where('is_active', true)
            ->role($role)
            ->when($caborId !== null, fn ($query) => $query->where('cabang_olahraga_id', $caborId))
            ->when($exceptUserId !== null, fn ($query) => $query->where('id', '!=', $exceptUserId))
            ->get();

        foreach ($users as $user) {
            self::toUser($user, $title, $message, $url, $category, $exceptUserId);
        }
    }

    public static function toCaborAdmins(
        int $caborId,
        string $title,
        string $message,
        string $url,
        string $category,
    ): void {
        self::toRole('admin_cabor', $title, $message, $url, $category, $caborId);
    }
}
