# KONI Klaten Patch 12.1

Koreksi kecil untuk Patch 12: mencegah notifikasi menggagalkan alur pengajuan prestasi ketika role penerima belum tersedia.

Lihat `PATCH-12.1-INSTRUKSI.md` untuk cara pemasangan dan pengujian.
