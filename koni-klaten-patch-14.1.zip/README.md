# KONI Klaten Patch 14.1

Bugfix untuk Patch 14:
- Memperbaiki Blade include feedback pada lima layout portal.
- Memperbaiki pemeriksaan registrasi Artisan command dalam DemoExperienceTest.

Lihat PATCH-14.1-INSTRUKSI.md untuk cara pemasangan.
