-- MySQL dump 10.13  Distrib 8.4.13, for Linux (x86_64)
--
-- Host: localhost    Database: laravel
-- ------------------------------------------------------
-- Server version	8.4.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agendas`
--

DROP TABLE IF EXISTS `agendas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agendas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cabang_olahraga_id` bigint unsigned DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `published_by` bigint unsigned DEFAULT NULL,
  `judul` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'kegiatan',
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `tanggal_mulai` date NOT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `waktu_mulai` time DEFAULT NULL,
  `waktu_selesai` time DEFAULT NULL,
  `lokasi` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `poster_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `catatan_revisi` text COLLATE utf8mb4_unicode_ci,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `agendas_slug_unique` (`slug`),
  KEY `agendas_created_by_foreign` (`created_by`),
  KEY `agendas_updated_by_foreign` (`updated_by`),
  KEY `agendas_published_by_foreign` (`published_by`),
  KEY `agendas_status_tanggal_mulai_index` (`status`,`tanggal_mulai`),
  KEY `agendas_cabang_olahraga_id_status_index` (`cabang_olahraga_id`,`status`),
  KEY `agendas_jenis_index` (`jenis`),
  KEY `agendas_tanggal_mulai_index` (`tanggal_mulai`),
  KEY `agendas_status_index` (`status`),
  CONSTRAINT `agendas_cabang_olahraga_id_foreign` FOREIGN KEY (`cabang_olahraga_id`) REFERENCES `cabang_olahraga` (`id`) ON DELETE SET NULL,
  CONSTRAINT `agendas_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `agendas_published_by_foreign` FOREIGN KEY (`published_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `agendas_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agendas`
--

LOCK TABLES `agendas` WRITE;
/*!40000 ALTER TABLE `agendas` DISABLE KEYS */;
INSERT INTO `agendas` VALUES (1,3,9,6,6,'lomba','lomba','agenda','lomba sepak bola koni klaten','2026-11-01','2026-11-01','03:50:00','15:50:00','koni klaten','agenda/dGbtZIIaXLeXAcHISko3ua56bx5Q4F1CK6tU4TYz.webp','published',NULL,'2026-11-11 15:51:20','2026-11-11 15:50:48','2026-11-11 15:51:20');
/*!40000 ALTER TABLE `agendas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `atlets`
--

DROP TABLE IF EXISTS `atlets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `atlets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cabang_olahraga_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `nama_lengkap` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_kelamin` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempat_lahir` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `no_telepon` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'aktif',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `custom_data` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `atlets_user_id_unique` (`user_id`),
  KEY `atlets_cabang_olahraga_id_foreign` (`cabang_olahraga_id`),
  KEY `atlets_status_index` (`status`),
  CONSTRAINT `atlets_cabang_olahraga_id_foreign` FOREIGN KEY (`cabang_olahraga_id`) REFERENCES `cabang_olahraga` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `atlets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atlets`
--

LOCK TABLES `atlets` WRITE;
/*!40000 ALTER TABLE `atlets` DISABLE KEYS */;
INSERT INTO `atlets` VALUES (2,2,4,'Naila Fath','P','klaten','2026-11-04','klaten','08123456789','fath@contoh.com','atlet/G7UJ3ERjKlqIVuuY81AbjQuNuvv7QlBrQEIUBSDQ.png','aktif','2026-11-08 06:34:44','2026-11-08 10:25:49',NULL),(3,3,11,'Josh','L','klaten','2026-07-09','korut','08123456789','sepak2@koniklaten.id','atlet/tqxFKlWqjTZnLHSKa9eZaN1L72A48s1kpvuzPzvK.jpg','aktif','2026-11-09 02:46:37','2026-11-09 02:53:36',NULL),(4,2,NULL,'sapa','L','klaten','2026-05-06','klaten','08123456789','aha@koniklaten.id','atlet/OT2NEJ6oNanPoYZM3jIeaOPn3rNVaW0ArJ1ESwov.webp','aktif','2026-11-09 04:16:57','2026-11-09 04:16:57',NULL),(5,3,12,'Mars','L','unknown','2025-05-08','unknown','08123456789','sepak4@koniklaten.id','atlet/awnQHGKAgqu5yKYnic5Exsf5dHgksKpOBkbyNwed.jpg','aktif','2026-11-09 04:21:55','2026-11-09 06:29:58',NULL),(6,4,14,'Jeonghan','L','Jawa','2025-11-01','Jakardah','0238897126','water2@koniklaten.id','atlet/28YBtt37UZw4YxjDvfeioMnTHEWkfHg2egQRaLO5.jpg','aktif','2026-11-11 16:42:12','2026-11-11 16:42:12',NULL);
/*!40000 ALTER TABLE `atlets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_records`
--

DROP TABLE IF EXISTS `attendance_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_records` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `attendance_session_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `cabang_olahraga_id` bigint unsigned DEFAULT NULL,
  `participant_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `participant_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_snapshot` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `selfie_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `check_out_selfie_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `checked_in_at` datetime NOT NULL,
  `checked_out_at` datetime DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attendance_records_attendance_session_id_user_id_unique` (`attendance_session_id`,`user_id`),
  KEY `attendance_records_user_id_foreign` (`user_id`),
  KEY `attendance_records_cabang_olahraga_id_foreign` (`cabang_olahraga_id`),
  KEY `att_rec_session_cabor_idx` (`attendance_session_id`,`cabang_olahraga_id`),
  CONSTRAINT `attendance_records_attendance_session_id_foreign` FOREIGN KEY (`attendance_session_id`) REFERENCES `attendance_sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `attendance_records_cabang_olahraga_id_foreign` FOREIGN KEY (`cabang_olahraga_id`) REFERENCES `cabang_olahraga` (`id`) ON DELETE SET NULL,
  CONSTRAINT `attendance_records_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_records`
--

LOCK TABLES `attendance_records` WRITE;
/*!40000 ALTER TABLE `attendance_records` DISABLE KEYS */;
INSERT INTO `attendance_records` VALUES (1,3,14,4,'Jeonghan','water2@koniklaten.id','atlet','absensi/3/14_check_in_20261122150108_pLihiHlK.jpg','absensi/3/14_check_out_20261122150127_7zAH0287.jpg','2026-11-22 15:01:08','2026-11-22 15:01:27','2400:9800:1f7:e959:8f68:4a0c:df5f:a627','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Mobile Safari/537.36','2026-11-22 15:01:08','2026-11-22 15:01:27'),(2,3,12,3,'Mars','sepak4@koniklaten.id','atlet','absensi/3/12_check_in_20261122163905_ku6tH3mO.jpg','absensi/3/12_check_out_20261122163924_z6WZqTJZ.jpg','2026-11-22 16:39:05','2026-11-22 16:39:24','2400:9800:1f7:e959:8f68:4a0c:df5f:a627','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Mobile Safari/537.36','2026-11-22 16:39:05','2026-11-22 16:39:24'),(3,4,12,3,'Mars','sepak4@koniklaten.id','atlet','absensi/4/12_check_in_20261125092233_MChmddvL.jpg','absensi/4/12_check_out_20261125092259_wSgusRL2.jpg','2026-11-25 09:22:33','2026-11-25 09:22:59','2400:9800:26f:18d1:3fd4:5771:56b7:d31d','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Mobile Safari/537.36','2026-11-25 09:22:33','2026-11-25 09:22:59');
/*!40000 ALTER TABLE `attendance_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_sessions`
--

DROP TABLE IF EXISTS `attendance_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_sessions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_by` bigint unsigned DEFAULT NULL,
  `cabang_olahraga_id` bigint unsigned DEFAULT NULL,
  `title` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `target_role` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all',
  `target_roles` json DEFAULT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `starts_at` datetime NOT NULL,
  `ends_at` datetime NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attendance_sessions_token_unique` (`token`),
  KEY `attendance_sessions_created_by_foreign` (`created_by`),
  KEY `attendance_sessions_cabang_olahraga_id_foreign` (`cabang_olahraga_id`),
  KEY `attendance_sessions_starts_at_index` (`starts_at`),
  KEY `attendance_sessions_ends_at_index` (`ends_at`),
  KEY `attendance_sessions_status_index` (`status`),
  CONSTRAINT `attendance_sessions_cabang_olahraga_id_foreign` FOREIGN KEY (`cabang_olahraga_id`) REFERENCES `cabang_olahraga` (`id`) ON DELETE SET NULL,
  CONSTRAINT `attendance_sessions_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_sessions`
--

LOCK TABLES `attendance_sessions` WRITE;
/*!40000 ALTER TABLE `attendance_sessions` DISABLE KEYS */;
INSERT INTO `attendance_sessions` VALUES (1,1,NULL,'Latihan',NULL,'all','[\"admin_koni\", \"staff_koni\", \"ketua_koni\", \"sekretaris_koni\", \"admin_cabor\", \"atlet\", \"pelatih\"]','MxX6iVEkvzyxqtBgaaiFzt5EqkKtnpcv0beKunGI','2026-11-21 19:27:00','2026-11-21 21:27:00','open','2026-11-21 19:27:23','2026-11-21 19:27:23'),(2,1,NULL,'Rapat',NULL,'all','[\"admin_koni\", \"staff_koni\", \"ketua_koni\", \"sekretaris_koni\", \"admin_cabor\", \"atlet\", \"pelatih\"]','zc7RIJH9vyOLZ6NHfn7SXOBYTFjO0yc8zptlcMzTro86ocUC','2026-11-21 21:49:00','2026-11-21 23:49:00','open','2026-11-21 21:50:15','2026-11-21 21:50:15'),(3,1,NULL,'RAKOR',NULL,'all','[\"admin_koni\", \"staff_koni\", \"ketua_koni\", \"sekretaris_koni\", \"admin_cabor\", \"atlet\", \"pelatih\"]','nNqTxTcPzkJ7SsVzp0mqOyQzQuNTXblwFLnt8HFyawMc5WyW','2026-11-22 14:51:00','2026-11-22 16:51:00','open','2026-11-22 14:51:54','2026-11-22 14:51:54'),(4,1,NULL,'koor',NULL,'all','[\"admin_koni\", \"staff_koni\", \"ketua_koni\", \"sekretaris_koni\", \"admin_cabor\", \"atlet\", \"pelatih\"]','3Cg0zKLx9ttpreOhmWnaRqzBhgA4pxrAhGbpZPDUHpoK45tm','2026-11-25 09:15:00','2026-11-25 11:15:00','open','2026-11-25 09:15:23','2026-11-25 09:15:23');
/*!40000 ALTER TABLE `attendance_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `actor_id` bigint unsigned DEFAULT NULL,
  `actor_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `actor_role` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` bigint unsigned DEFAULT NULL,
  `subject_label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cabang_olahraga_id` bigint unsigned DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `method` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `route_name` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_logs_created_at_index` (`created_at`),
  KEY `audit_logs_actor_id_created_at_index` (`actor_id`,`created_at`),
  KEY `audit_logs_cabang_olahraga_id_created_at_index` (`cabang_olahraga_id`,`created_at`),
  KEY `audit_logs_subject_type_subject_id_index` (`subject_type`,`subject_id`),
  KEY `audit_logs_event_index` (`event`),
  CONSTRAINT `audit_logs_actor_id_foreign` FOREIGN KEY (`actor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `audit_logs_cabang_olahraga_id_foreign` FOREIGN KEY (`cabang_olahraga_id`) REFERENCES `cabang_olahraga` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,17,'Ketua KONI','ketua_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-19 21:53:11',NULL),(2,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-19 21:53:18',NULL),(3,NULL,'System Backup','system','backup_created',NULL,NULL,'koni-db-20261120-100558-cqlpqptq.sql',NULL,NULL,'{\"sha256\": \"4ecc91a9a7bc3ee233b48d253315e4c5abf908528fa1cdb93cad2bf55fd32f9a\", \"database\": \"laravel\", \"size_bytes\": 67510}',NULL,'Artisan CLI','CLI',NULL,'2026-11-20 10:05:58',NULL),(4,NULL,'System Backup','system','backup_created',NULL,NULL,'koni-db-20261120-101858-cmrn4rgh.sql',NULL,NULL,'{\"sha256\": \"68976076acec07df2a37d5f7c0e13d9e4a01990c017d7318a212d4876db7d758\", \"database\": \"laravel\", \"size_bytes\": 67812}',NULL,'Artisan CLI','CLI',NULL,'2026-11-20 10:18:58',NULL),(5,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-20 10:22:38',NULL),(6,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-20 14:51:30',NULL),(7,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-21 14:24:04',NULL),(8,1,'Administrator KONI','admin_koni','updated','App\\Models\\User',1,'Administrator KONI',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-21 14:24:21',NULL),(9,1,'Administrator KONI','admin_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-21 14:24:21',NULL),(10,17,'Ketua KONI','ketua_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-21 14:24:36',NULL),(11,17,'Ketua KONI','ketua_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-21 14:25:23',NULL),(12,18,'Sekertaris KONI','sekretaris_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-21 14:25:32',NULL),(13,18,'Sekertaris KONI','sekretaris_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-21 14:25:53',NULL),(14,9,'charles','admin_cabor','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-21 14:26:02',NULL),(15,9,'charles','admin_cabor','password_changed','App\\Models\\User',9,'charles',3,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','PUT','account.password.update','2026-11-21 14:27:13',NULL),(16,9,'charles','admin_cabor','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-21 14:28:04',NULL),(17,10,'charles','pelatih','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-21 14:28:15',NULL),(18,10,'charles','pelatih','password_changed','App\\Models\\User',10,'charles',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','PUT','account.password.update','2026-11-21 14:28:32',NULL),(19,10,'charles','pelatih','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-21 14:28:51',NULL),(20,11,'josh','atlet','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-21 14:29:01',NULL),(21,11,'josh','atlet','password_changed','App\\Models\\User',11,'josh',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','PUT','account.password.update','2026-11-21 14:29:21',NULL),(22,11,'josh','atlet','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-21 14:40:22',NULL),(23,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-21 14:40:30',NULL),(24,9,'charles','admin_cabor','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-21 14:42:42',NULL),(25,9,'charles','admin_cabor','created','App\\Models\\InventoryCategory',1,'Umum',3,NULL,'{\"nama\": \"Umum\", \"deskripsi\": \"Umum\", \"created_by\": 9, \"cabang_olahraga_id\": 3}','172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','cabor.inventaris.kategori.store','2026-11-21 14:43:27',NULL),(26,9,'charles','admin_cabor','created','App\\Models\\InventoryItem',1,'Bola',3,NULL,'{\"jumlah\": \"1\", \"lokasi\": \"Gudang\", \"satuan\": \"unit\", \"status\": \"aktif\", \"kondisi\": \"baik\", \"deskripsi\": null, \"created_by\": 9, \"updated_by\": 9, \"nama_barang\": \"Bola\", \"harga_perolehan\": \"10000\", \"tanggal_perolehan\": \"2026-11-21 00:00:00\", \"cabang_olahraga_id\": 3, \"inventory_category_id\": \"1\"}','172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','cabor.inventaris.store','2026-11-21 14:44:32',NULL),(27,9,'charles','admin_cabor','updated','App\\Models\\InventoryItem',1,'Bola',3,'{\"kode_barang\": null}','{\"kode_barang\": \"INV-CABOR[nomor kontak disamarkan]\"}','172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','cabor.inventaris.store','2026-11-21 14:44:32',NULL),(28,9,'charles','admin_cabor','deleted','App\\Models\\InventoryItem',1,'Bola',3,'{\"jumlah\": 1, \"lokasi\": \"Gudang\", \"satuan\": \"unit\", \"status\": \"aktif\", \"kondisi\": \"baik\", \"deskripsi\": null, \"created_by\": 9, \"updated_by\": 9, \"kode_barang\": \"INV-CABOR[nomor kontak disamarkan]\", \"nama_barang\": \"Bola\", \"harga_perolehan\": \"10000.00\", \"tanggal_perolehan\": \"2026-11-21\", \"cabang_olahraga_id\": 3, \"inventory_category_id\": 1}',NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','DELETE','cabor.inventaris.destroy','2026-11-21 14:44:44',NULL),(29,9,'charles','admin_cabor','created','App\\Models\\InventoryItem',2,'Bola',3,NULL,'{\"jumlah\": \"1\", \"lokasi\": \"Gudang\", \"satuan\": \"unit\", \"status\": \"aktif\", \"kondisi\": \"baik\", \"deskripsi\": null, \"created_by\": 9, \"updated_by\": 9, \"nama_barang\": \"Bola\", \"harga_perolehan\": \"10.000\", \"tanggal_perolehan\": null, \"cabang_olahraga_id\": 3, \"inventory_category_id\": \"1\"}','172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','cabor.inventaris.store','2026-11-21 14:46:19',NULL),(30,9,'charles','admin_cabor','updated','App\\Models\\InventoryItem',2,'Bola',3,'{\"kode_barang\": null}','{\"kode_barang\": \"INV-CABOR[nomor kontak disamarkan]\"}','172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','cabor.inventaris.store','2026-11-21 14:46:19',NULL),(31,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-21 19:25:00',NULL),(32,1,'Administrator KONI','admin_koni','updated','App\\Models\\User',1,'Administrator KONI',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-21 19:26:10',NULL),(33,1,'Administrator KONI','admin_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-21 19:26:10',NULL),(34,9,'charles','admin_cabor','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-21 19:26:26',NULL),(35,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-21 19:26:58',NULL),(36,9,'charles','admin_cabor','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-21 19:27:46',NULL),(37,11,'josh','atlet','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-21 19:27:55',NULL),(38,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-21 21:43:41',NULL),(39,11,'josh','atlet','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-21 21:51:16',NULL),(40,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-22 14:48:09',NULL),(41,1,'Administrator KONI','admin_koni','updated','App\\Models\\User',1,'Administrator KONI',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-22 14:52:06',NULL),(42,1,'Administrator KONI','admin_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-22 14:52:06',NULL),(43,11,'josh','atlet','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-22 14:52:24',NULL),(44,11,'josh','atlet','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-22 14:58:01',NULL),(45,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-22 14:58:06',NULL),(46,14,'Jeonghan','atlet','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'2400:9800:1f7:e959:8f68:4a0c:df5f:a627','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Mobile Safari/537.36','POST','login.store','2026-11-22 14:58:47',NULL),(47,14,'Jeonghan','atlet','password_changed','App\\Models\\User',14,'Jeonghan',NULL,NULL,NULL,'2400:9800:1f7:e959:8f68:4a0c:df5f:a627','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Mobile Safari/537.36','PUT','account.password.update','2026-11-22 15:00:21',NULL),(48,14,'Jeonghan','atlet','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'2400:9800:1f7:e959:8f68:4a0c:df5f:a627','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Mobile Safari/537.36','POST','logout','2026-11-22 15:40:34',NULL),(49,11,'josh','atlet','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'2400:9800:1f7:e959:8f68:4a0c:df5f:a627','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Mobile Safari/537.36','POST','login.store','2026-11-22 15:40:58',NULL),(50,1,'Administrator KONI','admin_koni','updated','App\\Models\\User',1,'Administrator KONI',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-22 15:41:52',NULL),(51,1,'Administrator KONI','admin_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-22 15:41:52',NULL),(52,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-22 15:42:15',NULL),(53,1,'Administrator KONI','admin_koni','updated','App\\Models\\User',1,'Administrator KONI',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-22 15:42:45',NULL),(54,1,'Administrator KONI','admin_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-22 15:42:45',NULL),(55,12,'Mars','atlet','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-22 15:42:52',NULL),(56,12,'Mars','atlet','password_changed','App\\Models\\User',12,'Mars',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','PUT','account.password.update','2026-11-22 15:43:20',NULL),(57,12,'Mars','atlet','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-22 15:43:56',NULL),(58,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-22 15:44:04',NULL),(59,12,'Mars','atlet','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-22 15:44:59',NULL),(60,12,'Mars','atlet','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'2400:9800:1f7:e959:8f68:4a0c:df5f:a627','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Mobile Safari/537.36','POST','login.store','2026-11-22 15:57:33',NULL),(61,12,'Mars','atlet','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'2400:9800:1f7:e959:8f68:4a0c:df5f:a627','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Mobile Safari/537.36','POST','login.store','2026-11-22 15:59:39',NULL),(62,12,'Mars','atlet','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'2400:9800:1f7:e959:8f68:4a0c:df5f:a627','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Mobile Safari/537.36','POST','login.store','2026-11-22 16:13:10',NULL),(63,12,'Mars','atlet','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'2400:9800:1f7:e959:8f68:4a0c:df5f:a627','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Mobile Safari/537.36','POST','login.store','2026-11-22 16:38:16',NULL),(64,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-24 20:42:02',NULL),(65,17,'Ketua KONI','ketua_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-25 08:00:41',NULL),(66,17,'Ketua KONI','ketua_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','logout','2026-11-25 09:14:44',NULL),(67,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','POST','login.store','2026-11-25 09:14:55',NULL),(68,12,'Mars','atlet','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'2400:9800:26f:18d1:3fd4:5771:56b7:d31d','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Mobile Safari/537.36','POST','login.store','2026-11-25 09:16:52',NULL),(69,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 06:24:31',NULL),(70,1,'Administrator KONI','admin_koni','updated','App\\Models\\User',1,'Administrator KONI',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 06:24:44',NULL),(71,1,'Administrator KONI','admin_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 06:24:44',NULL),(72,17,'Ketua KONI','ketua_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 06:24:57',NULL),(73,17,'Ketua KONI','ketua_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 06:25:43',NULL),(74,18,'Sekertaris KONI','sekretaris_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 06:25:54',NULL),(75,18,'Sekertaris KONI','sekretaris_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 06:26:23',NULL),(76,9,'charles','admin_cabor','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 06:26:53',NULL),(77,6,'staf koni','staff_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 06:27:50',NULL),(78,6,'staf koni','staff_koni','password_changed','App\\Models\\User',6,'staf koni',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','PUT','account.password.update','2026-11-26 06:28:21',NULL),(79,9,'charles','admin_cabor','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 07:41:55',NULL),(80,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 07:42:59',NULL),(81,1,'Administrator KONI','admin_koni','updated','App\\Models\\User',1,'Administrator KONI',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 07:44:21',NULL),(82,1,'Administrator KONI','admin_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 07:44:22',NULL),(83,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 07:47:23',NULL),(84,1,'Administrator KONI','admin_koni','updated','App\\Models\\User',1,'Administrator KONI',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 07:48:25',NULL),(85,1,'Administrator KONI','admin_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 07:48:25',NULL),(86,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 07:49:50',NULL),(87,1,'Administrator KONI','admin_koni','updated','App\\Models\\User',1,'Administrator KONI',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 07:50:46',NULL),(88,1,'Administrator KONI','admin_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 07:50:46',NULL),(89,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 07:57:33',NULL),(90,1,'Administrator KONI','admin_koni','updated','App\\Models\\User',1,'Administrator KONI',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 09:59:07',NULL),(91,1,'Administrator KONI','admin_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 09:59:08',NULL),(92,17,'Ketua KONI','ketua_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 09:59:22',NULL),(93,17,'Ketua KONI','ketua_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 10:56:35',NULL),(94,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 10:56:44',NULL),(95,1,'Administrator KONI','admin_koni','updated','App\\Models\\User',1,'Administrator KONI',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 10:57:03',NULL),(96,1,'Administrator KONI','admin_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 10:57:03',NULL),(97,17,'Ketua KONI','ketua_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 10:58:27',NULL),(98,17,'Ketua KONI','ketua_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 10:58:47',NULL),(99,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 10:58:58',NULL),(100,1,'Administrator KONI','admin_koni','updated','App\\Models\\User',1,'Administrator KONI',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 11:00:08',NULL),(101,1,'Administrator KONI','admin_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 11:00:08',NULL),(102,17,'Ketua KONI','ketua_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 11:00:22',NULL),(103,17,'Ketua KONI','ketua_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 11:13:42',NULL),(104,18,'Sekertaris KONI','sekretaris_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 11:13:53',NULL),(105,18,'Sekertaris KONI','sekretaris_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 11:15:18',NULL),(106,6,'staf koni','staff_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 11:15:36',NULL),(107,6,'staf koni','staff_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 11:16:35',NULL),(108,9,'charles','admin_cabor','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 11:16:58',NULL),(109,9,'charles','admin_cabor','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 11:20:19',NULL),(110,17,'Ketua KONI','ketua_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 11:20:27',NULL),(111,17,'Ketua KONI','ketua_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 11:20:49',NULL),(112,1,'Administrator KONI','admin_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 11:21:03',NULL),(113,1,'Administrator KONI','admin_koni','updated','App\\Models\\User',1,'Administrator KONI',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 11:23:01',NULL),(114,1,'Administrator KONI','admin_koni','logout',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','logout','2026-11-26 11:23:01',NULL),(115,17,'Ketua KONI','ketua_koni','login',NULL,NULL,'Sesi pengguna',NULL,NULL,NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','POST','login.store','2026-11-26 11:23:11',NULL);
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cabang_olahraga`
--

DROP TABLE IF EXISTS `cabang_olahraga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cabang_olahraga` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `singkatan` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `logo_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama_ketua` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telepon` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'aktif',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cabang_olahraga_nama_unique` (`nama`),
  KEY `cabang_olahraga_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cabang_olahraga`
--

LOCK TABLES `cabang_olahraga` WRITE;
/*!40000 ALTER TABLE `cabang_olahraga` DISABLE KEYS */;
INSERT INTO `cabang_olahraga` VALUES (2,'Bulutangkis','PBSI',NULL,'cabor/8jqiKoW8sY8Wafww00UlBA6LnxeOoM2VQojjzBNP.jpg','Kakanda','bulutangkis@koniklaten.com','08123456789','klaten','aktif','2026-11-08 06:30:32','2026-11-08 06:30:32'),(3,'Sepak Bola','PSSI','Sepak bola adalah permainan olahraga beregu yang dimainkan oleh dua tim, di mana masing-masing tim beranggotakan 11 pemain','cabor/wqo3gT6SbvKFRUQBwOlwb9BDY0pUGa1EfBAfcniI.webp','Charles','sepak@koniklaten.id','08987654321','Korea Utara','aktif','2026-11-09 02:45:01','2026-11-09 02:45:01'),(4,'Water Sport','Akuatik','Watersport atau olahraga air adalah berbagai aktivitas rekreasi dan olahraga yang dilakukan di atas, di dalam, atau di bawah permukaan air. Aktivitas ini memadukan keseruan, tantangan adrenalin, serta kebugaran fisik, dan biasanya dilakukan di pantai, danau, sungai, maupun kolam renang.','cabor/GHXPGZI66xWOGULtqLUFGCXe9DCwqSLKLWn7kv8p.jpg','DK','water@koniklaten.id','0378945612','mana aja','aktif','2026-11-11 16:37:19','2026-11-11 16:37:19');
/*!40000 ALTER TABLE `cabang_olahraga` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields`
--

DROP TABLE IF EXISTS `custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_fields` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `entity_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_key` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `options` json DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` smallint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `custom_fields_entity_type_field_key_unique` (`entity_type`,`field_key`),
  KEY `custom_fields_entity_type_is_active_sort_order_index` (`entity_type`,`is_active`,`sort_order`),
  KEY `custom_fields_entity_type_index` (`entity_type`),
  KEY `custom_fields_is_active_index` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields`
--

LOCK TABLES `custom_fields` WRITE;
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
INSERT INTO `custom_fields` VALUES (1,'atlet','NIK','nik','text',NULL,1,1,1,'2026-11-21 21:52:49','2026-11-21 21:52:49');
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_settings`
--

DROP TABLE IF EXISTS `dashboard_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `backdrop_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `overlay_opacity` tinyint unsigned NOT NULL DEFAULT '55',
  `background_position` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'center',
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dashboard_settings_updated_by_foreign` (`updated_by`),
  CONSTRAINT `dashboard_settings_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_settings`
--

LOCK TABLES `dashboard_settings` WRITE;
/*!40000 ALTER TABLE `dashboard_settings` DISABLE KEYS */;
INSERT INTO `dashboard_settings` VALUES (1,NULL,55,'center',NULL,'2026-11-21 19:10:45','2026-11-21 19:10:45');
/*!40000 ALTER TABLE `dashboard_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_categories`
--

DROP TABLE IF EXISTS `inventory_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cabang_olahraga_id` bigint unsigned DEFAULT NULL,
  `nama` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_categories_scope_name_unique` (`cabang_olahraga_id`,`nama`),
  KEY `inventory_categories_created_by_foreign` (`created_by`),
  KEY `inventory_categories_cabang_olahraga_id_index` (`cabang_olahraga_id`),
  CONSTRAINT `inventory_categories_cabang_olahraga_id_foreign` FOREIGN KEY (`cabang_olahraga_id`) REFERENCES `cabang_olahraga` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `inventory_categories_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_categories`
--

LOCK TABLES `inventory_categories` WRITE;
/*!40000 ALTER TABLE `inventory_categories` DISABLE KEYS */;
INSERT INTO `inventory_categories` VALUES (1,3,'Umum','Umum',9,'2026-11-21 14:43:27','2026-11-21 14:43:27');
/*!40000 ALTER TABLE `inventory_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_items`
--

DROP TABLE IF EXISTS `inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kode_barang` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inventory_category_id` bigint unsigned NOT NULL,
  `cabang_olahraga_id` bigint unsigned DEFAULT NULL,
  `nama_barang` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `jumlah` int unsigned NOT NULL DEFAULT '1',
  `satuan` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unit',
  `kondisi` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'baik',
  `lokasi` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_perolehan` date DEFAULT NULL,
  `harga_perolehan` decimal(15,2) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'aktif',
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_items_kode_barang_unique` (`kode_barang`),
  KEY `inventory_items_created_by_foreign` (`created_by`),
  KEY `inventory_items_updated_by_foreign` (`updated_by`),
  KEY `inventory_items_cabang_olahraga_id_status_index` (`cabang_olahraga_id`,`status`),
  KEY `inventory_items_inventory_category_id_kondisi_index` (`inventory_category_id`,`kondisi`),
  KEY `inventory_items_kondisi_index` (`kondisi`),
  KEY `inventory_items_status_index` (`status`),
  CONSTRAINT `inventory_items_cabang_olahraga_id_foreign` FOREIGN KEY (`cabang_olahraga_id`) REFERENCES `cabang_olahraga` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `inventory_items_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inventory_items_inventory_category_id_foreign` FOREIGN KEY (`inventory_category_id`) REFERENCES `inventory_categories` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `inventory_items_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_items`
--

LOCK TABLES `inventory_items` WRITE;
/*!40000 ALTER TABLE `inventory_items` DISABLE KEYS */;
INSERT INTO `inventory_items` VALUES (1,'INV-CABOR003-2026-000001',1,3,'Bola',NULL,1,'unit','baik','Gudang','2026-11-21',10000.00,'aktif',9,9,'2026-11-21 14:44:32','2026-11-21 14:44:44','2026-11-21 14:44:44'),(2,'INV-CABOR003-2026-000002',1,3,'Bola',NULL,1,'unit','baik','Gudang',NULL,10.00,'aktif',9,9,'2026-11-21 14:46:19','2026-11-21 14:46:19',NULL);
/*!40000 ALTER TABLE `inventory_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_loans`
--

DROP TABLE IF EXISTS `inventory_loans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_loans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `inventory_item_id` bigint unsigned NOT NULL,
  `peminjam` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kontak_peminjam` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_peminjam` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jumlah` int unsigned NOT NULL,
  `tanggal_pinjam` date NOT NULL,
  `batas_pengembalian` date NOT NULL,
  `tanggal_dikembalikan` timestamp NULL DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'dipinjam',
  `kondisi_pengembalian` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `catatan_pengembalian` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned DEFAULT NULL,
  `returned_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_loans_created_by_foreign` (`created_by`),
  KEY `inventory_loans_returned_by_foreign` (`returned_by`),
  KEY `inventory_loans_inventory_item_id_status_index` (`inventory_item_id`,`status`),
  KEY `inventory_loans_status_batas_pengembalian_index` (`status`,`batas_pengembalian`),
  KEY `inventory_loans_status_index` (`status`),
  CONSTRAINT `inventory_loans_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inventory_loans_inventory_item_id_foreign` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_items` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `inventory_loans_returned_by_foreign` FOREIGN KEY (`returned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_loans`
--

LOCK TABLES `inventory_loans` WRITE;
/*!40000 ALTER TABLE `inventory_loans` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_loans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_movements`
--

DROP TABLE IF EXISTS `inventory_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_movements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `inventory_item_id` bigint unsigned NOT NULL,
  `lokasi_asal` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lokasi_tujuan` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jumlah` int unsigned NOT NULL DEFAULT '1',
  `tanggal_mutasi` timestamp NOT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `moved_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_movements_moved_by_foreign` (`moved_by`),
  KEY `inventory_movements_inventory_item_id_tanggal_mutasi_index` (`inventory_item_id`,`tanggal_mutasi`),
  CONSTRAINT `inventory_movements_inventory_item_id_foreign` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_items` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `inventory_movements_moved_by_foreign` FOREIGN KEY (`moved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_movements`
--

LOCK TABLES `inventory_movements` WRITE;
/*!40000 ALTER TABLE `inventory_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `izin_latihans`
--

DROP TABLE IF EXISTS `izin_latihans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `izin_latihans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `cabang_olahraga_id` bigint unsigned NOT NULL,
  `jenis_pemohon` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_pemohon` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tujuan` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keperluan` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'diajukan',
  `catatan_admin` text COLLATE utf8mb4_unicode_ci,
  `diproses_oleh` bigint unsigned DEFAULT NULL,
  `diproses_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `izin_latihans_cabang_olahraga_id_created_at_index` (`cabang_olahraga_id`,`created_at`),
  KEY `izin_latihans_user_id_created_at_index` (`user_id`,`created_at`),
  KEY `izin_latihans_status_index` (`status`),
  KEY `izin_latihans_diproses_oleh_foreign` (`diproses_oleh`),
  CONSTRAINT `izin_latihans_cabang_olahraga_id_foreign` FOREIGN KEY (`cabang_olahraga_id`) REFERENCES `cabang_olahraga` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `izin_latihans_diproses_oleh_foreign` FOREIGN KEY (`diproses_oleh`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `izin_latihans_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `izin_latihans`
--

LOCK TABLES `izin_latihans` WRITE;
/*!40000 ALTER TABLE `izin_latihans` DISABLE KEYS */;
INSERT INTO `izin_latihans` VALUES (1,12,3,'atlet','Mars','Admin Cabor Sepak Bola','Sakit','2026-11-11','2026-11-11','izin-latihan/atlet/5/aVkI67RK2czVMYU2EG2VSCrvjOpowhSaFbQj8E8j.docx','Surat Tugas.docx','disetujui',NULL,9,'2026-11-11 16:37:57','2026-11-11 15:36:52','2026-11-11 16:37:57'),(2,10,3,'pelatih','Charles','Admin Cabor','Sakit','2026-11-11','2026-11-11','izin-latihan/pelatih/3/DIoUL5wIk8jsHMjx1pV3LidVG2MRFYye1gub2J5G.docx','Surat Tugas.docx','ditolak','jangan',9,'2026-11-11 16:37:53','2026-11-11 15:37:31','2026-11-11 16:37:53');
/*!40000 ALTER TABLE `izin_latihans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_11_08_042603_add_two_factor_columns_to_users_table',2),(5,'2026_11_08_042604_create_passkeys_table',2),(6,'2026_11_08_042618_create_permission_tables',2),(7,'2026_11_08_054237_create_cabang_olahragas_table',3),(8,'2026_11_08_061751_create_atlets_table',4),(9,'2026_11_08_070905_create_pelatihs_table',5),(10,'2026_11_08_073326_create_penguruses_table',6),(11,'2026_11_08_085400_add_cabang_olahraga_and_is_active_to_users_table',7),(12,'2026_11_11_000001_create_agendas_table',8),(13,'2026_11_11_000002_create_surats_table',9),(14,'2026_11_11_000003_create_prestasis_table',10),(15,'2026_11_11_000004_create_izin_latihans_table',10),(16,'2026_11_11_000005_add_jenis_medali_to_prestasis_table',11),(17,'2026_11_11_000006_create_publikasis_table',12),(18,'2026_11_11_000007_create_profil_koni_table',13),(19,'2026_11_11_000008_add_decision_and_account_fields',14),(20,'2026_11_11_000009_create_notifications_table',15),(21,'2026_11_19_000001_add_decision_by_role_to_surats_table',16),(22,'2026_11_19_000002_create_inventory_categories_table',17),(23,'2026_11_19_000003_create_inventory_items_table',17),(24,'2026_11_19_000004_create_inventory_movements_table',17),(25,'2026_11_19_000005_create_inventory_loans_table',17),(26,'2026_11_19_000006_create_audit_logs_table',18),(27,'2026_11_20_000001_add_password_security_fields_to_users_table',19),(28,'2026_11_21_000001_create_custom_fields_and_profile_custom_data',20),(29,'2026_11_21_000002_create_dashboard_settings_table',20),(30,'2026_11_21_000003_create_attendance_tables',21),(31,'2026_11_21_000004_extend_attendance_for_internal_roles_and_checkout',22),(32,'2026_11_21_000005_create_website_appearance_settings_table',22),(33,'2026_11_26_000001_create_surat_messages_table',23);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (4,'App\\Models\\User',1),(5,'App\\Models\\User',4),(3,'App\\Models\\User',6),(2,'App\\Models\\User',7),(6,'App\\Models\\User',8),(2,'App\\Models\\User',9),(6,'App\\Models\\User',10),(5,'App\\Models\\User',11),(5,'App\\Models\\User',12),(2,'App\\Models\\User',13),(5,'App\\Models\\User',14),(6,'App\\Models\\User',15),(3,'App\\Models\\User',16),(7,'App\\Models\\User',17),(8,'App\\Models\\User',18);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`),
  KEY `notifications_owner_read_index` (`notifiable_type`,`notifiable_id`,`read_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('140690ff-610a-44eb-ba5c-096421295826','App\\Notifications\\WorkflowNotification','App\\Models\\User',17,'{\"title\":\"Surat menunggu persetujuan Ketua KONI\",\"message\":\"Staff KONI meneruskan surat \\\"gor\\\". Ketua atau Sekretaris KONI dapat memberikan keputusan secara mandiri.\",\"url\":\"\\/admin\\/persuratan\\/2\",\"category\":\"persuratan\"}','2026-11-19 21:41:55','2026-11-19 21:41:08','2026-11-19 21:41:55'),('361d1fc9-586b-4b14-9e03-d594b9d798ab','App\\Notifications\\WorkflowNotification','App\\Models\\User',6,'{\"title\":\"Surat baru menunggu pemeriksaan\",\"message\":\"Cabang Sepak Bola mengajukan surat \\\"gor\\\".\",\"url\":\"\\/staff\\/surat\\/2\",\"category\":\"persuratan\"}','2026-11-19 21:41:04','2026-11-19 21:40:47','2026-11-19 21:41:04'),('3f7b84ea-b874-4a4a-8f72-00b28c0b410b','App\\Notifications\\WorkflowNotification','App\\Models\\User',1,'{\"title\":\"Surat menunggu keputusan\",\"message\":\"Staff KONI meneruskan surat \\\"gor\\\". Ketua atau Sekretaris KONI dapat memberikan keputusan secara mandiri.\",\"url\":\"\\/admin\\/persuratan\\/2\",\"category\":\"persuratan\"}','2026-11-19 21:53:48','2026-11-19 21:41:08','2026-11-19 21:53:48'),('84e76b89-9b8d-47fe-9896-c04848da9aca','App\\Notifications\\WorkflowNotification','App\\Models\\User',18,'{\"title\":\"Surat menunggu persetujuan Sekretaris KONI\",\"message\":\"Staff KONI meneruskan surat \\\"gor\\\". Ketua atau Sekretaris KONI dapat memberikan keputusan secara mandiri.\",\"url\":\"\\/sekretaris\\/surat\\/2\",\"category\":\"persuratan\"}','2026-11-19 21:41:37','2026-11-19 21:41:08','2026-11-19 21:41:37'),('d933f152-6418-4fa2-b043-2c8cce656610','App\\Notifications\\WorkflowNotification','App\\Models\\User',16,'{\"title\":\"Surat baru menunggu pemeriksaan\",\"message\":\"Cabang Sepak Bola mengajukan surat \\\"gor\\\".\",\"url\":\"\\/staff\\/surat\\/2\",\"category\":\"persuratan\"}',NULL,'2026-11-19 21:40:47','2026-11-19 21:40:47');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passkeys`
--

DROP TABLE IF EXISTS `passkeys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `passkeys` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `credential_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `credential` json NOT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `passkeys_credential_id_unique` (`credential_id`),
  KEY `passkeys_user_id_index` (`user_id`),
  CONSTRAINT `passkeys_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passkeys`
--

LOCK TABLES `passkeys` WRITE;
/*!40000 ALTER TABLE `passkeys` DISABLE KEYS */;
/*!40000 ALTER TABLE `passkeys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pelatihs`
--

DROP TABLE IF EXISTS `pelatihs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pelatihs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cabang_olahraga_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `nama_lengkap` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_kelamin` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempat_lahir` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `no_telepon` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendidikan_terakhir` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `spesialisasi` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sertifikasi` text COLLATE utf8mb4_unicode_ci,
  `pengalaman_tahun` tinyint unsigned DEFAULT NULL,
  `foto_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'aktif',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `custom_data` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pelatihs_user_id_unique` (`user_id`),
  KEY `pelatihs_cabang_olahraga_id_foreign` (`cabang_olahraga_id`),
  KEY `pelatihs_status_index` (`status`),
  CONSTRAINT `pelatihs_cabang_olahraga_id_foreign` FOREIGN KEY (`cabang_olahraga_id`) REFERENCES `cabang_olahraga` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `pelatihs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pelatihs`
--

LOCK TABLES `pelatihs` WRITE;
/*!40000 ALTER TABLE `pelatihs` DISABLE KEYS */;
INSERT INTO `pelatihs` VALUES (2,2,8,'kakandaa','L','klaten','2026-09-30','klaten','08123456789','bulu@contoh.com','S1','teknik','ada',1,'pelatih/rhAHojm39dEZ5MBEh4x4OByY7RK64OfwBeWM2ODr.png','aktif','2026-11-08 07:20:19','2026-11-09 02:50:21',NULL),(3,3,10,'Charles','L','klaten','2023-02-14','korsel','08123456789','sepak1@koniklaten.id','S2','jago','best liar',12,'pelatih/FM965vXF0QwgcmE3jZSkBwhVs6ynqdSPQ9Jamjo4.webp','aktif','2026-11-09 02:48:11','2026-11-09 06:38:51',NULL),(4,3,NULL,'Vernon','L','California','2025-07-04','LA','08123456789','sepak3@koniklaten.id','S1','jago','ada',7,'pelatih/BAJzzW0j9agmLQqfLEROaRQCkfh2TgCyZAlxj8AY.jpg','aktif','2026-11-09 04:19:57','2026-11-09 04:19:57',NULL),(5,4,15,'Wonu','L','Solo','2022-08-02','Yogyakarta','351619135161','water1@koniklaten.id','S1','terbang','Internasional',5,'pelatih/7h5hwiaFUHAnnPHCUkv7kCEapc03U2kN3aexrtEU.jpg','aktif','2026-11-11 16:44:52','2026-11-11 16:44:53',NULL);
/*!40000 ALTER TABLE `pelatihs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pengurus`
--

DROP TABLE IF EXISTS `pengurus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pengurus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `cabang_olahraga_id` bigint unsigned DEFAULT NULL,
  `nama_lengkap` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jabatan` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bidang` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jenis_kelamin` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `periode_mulai` smallint unsigned DEFAULT NULL,
  `periode_selesai` smallint unsigned DEFAULT NULL,
  `no_telepon` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `urutan` smallint unsigned NOT NULL DEFAULT '0',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'aktif',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pengurus_user_id_unique` (`user_id`),
  KEY `pengurus_cabang_olahraga_id_foreign` (`cabang_olahraga_id`),
  KEY `pengurus_status_index` (`status`),
  CONSTRAINT `pengurus_cabang_olahraga_id_foreign` FOREIGN KEY (`cabang_olahraga_id`) REFERENCES `cabang_olahraga` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `pengurus_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pengurus`
--

LOCK TABLES `pengurus` WRITE;
/*!40000 ALTER TABLE `pengurus` DISABLE KEYS */;
INSERT INTO `pengurus` VALUES (1,NULL,NULL,'Parwanto','Ketua Umum','UMUM','L',2023,2028,'08123456789','ffath@contoh.com','pengurus/4rxXm0n6fE0jjuORX5fFpoR76eS0tssXZ3vgOMOb.jpg',1,'aktif','2026-11-08 08:29:40','2026-11-08 08:29:40'),(2,NULL,2,'kakanda','Ketua Umum','UMUM','L',2025,2029,'08123456789','fath@contoh.com','pengurus/t6suwWxa54cmIfaeljI63nKeFdubVuCqotvHTUWF.png',1,'aktif','2026-11-08 08:30:44','2026-11-08 08:30:44'),(3,NULL,2,'sapa','Sekertaris','pembinaan prestasi','L',2025,2029,'08978654321',NULL,'pengurus/JykLsWQ0L1TOZFEIgOXKJBzd3YW72TZKSRRFRDC7.jpg',2,'aktif','2026-11-09 05:28:50','2026-11-09 05:28:50'),(4,16,NULL,'Mingyu','Bendahara','UMUM','L',2025,2029,'211516135164','bend@koniklaten.id','pengurus/6XDMOfcqO8BDM9j9arJYKkDH7KlU1MJ26SN59i5L.png',3,'aktif','2026-11-11 16:48:41','2026-11-11 16:49:25');
/*!40000 ALTER TABLE `pengurus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestasis`
--

DROP TABLE IF EXISTS `prestasis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prestasis` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `atlet_id` bigint unsigned DEFAULT NULL,
  `pelatih_id` bigint unsigned DEFAULT NULL,
  `cabang_olahraga_id` bigint unsigned NOT NULL,
  `verified_by` bigint unsigned DEFAULT NULL,
  `nama_kejuaraan` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tingkat` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hasil` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `penyelenggara` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_prestasi` date NOT NULL,
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `bukti_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bukti_original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'menunggu_verifikasi',
  `catatan_verifikasi` text COLLATE utf8mb4_unicode_ci,
  `verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `jenis_medali` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prestasis_pelatih_id_foreign` (`pelatih_id`),
  KEY `prestasis_verified_by_foreign` (`verified_by`),
  KEY `prestasis_cabang_olahraga_id_status_index` (`cabang_olahraga_id`,`status`),
  KEY `prestasis_atlet_id_status_index` (`atlet_id`,`status`),
  KEY `prestasis_tingkat_index` (`tingkat`),
  KEY `prestasis_tanggal_prestasi_index` (`tanggal_prestasi`),
  KEY `prestasis_status_index` (`status`),
  KEY `prestasis_jenis_medali_index` (`jenis_medali`),
  CONSTRAINT `prestasis_atlet_id_foreign` FOREIGN KEY (`atlet_id`) REFERENCES `atlets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prestasis_cabang_olahraga_id_foreign` FOREIGN KEY (`cabang_olahraga_id`) REFERENCES `cabang_olahraga` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `prestasis_pelatih_id_foreign` FOREIGN KEY (`pelatih_id`) REFERENCES `pelatihs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prestasis_verified_by_foreign` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestasis`
--

LOCK TABLES `prestasis` WRITE;
/*!40000 ALTER TABLE `prestasis` DISABLE KEYS */;
INSERT INTO `prestasis` VALUES (1,5,NULL,3,9,'sepak bola','lokal','10','juara 1','koni','2026-11-01',NULL,'prestasi/atlet/5/Erc23AyjuWCMBk7avzYXD3RlUSrmegu26XA5ygx2.pdf','Proposal Kegiatan Magang Sapuangin.pdf','ditolak','jangan','2026-11-11 16:38:42','2026-11-11 15:45:52','2026-11-11 16:38:42','emas'),(2,NULL,3,3,9,'sepak bola','lokal','10','Juara 1','koni','2026-11-01',NULL,'prestasi/pelatih/3/SZ671rADsOZyO7fNTSZEExa6MgEJWrJV3zmKiVkw.pdf','Proposal Kegiatan Magang Sapuangin.pdf','terverifikasi',NULL,'2026-11-11 15:47:05','2026-11-11 15:46:47','2026-11-11 15:47:05','emas');
/*!40000 ALTER TABLE `prestasis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profil_koni`
--

DROP TABLE IF EXISTS `profil_koni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profil_koni` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nama_organisasi` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_singkat` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tagline` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `sejarah` longtext COLLATE utf8mb4_unicode_ci,
  `visi` text COLLATE utf8mb4_unicode_ci,
  `misi` text COLLATE utf8mb4_unicode_ci,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `telepon` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `profil_koni_updated_by_foreign` (`updated_by`),
  CONSTRAINT `profil_koni_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profil_koni`
--

LOCK TABLES `profil_koni` WRITE;
/*!40000 ALTER TABLE `profil_koni` DISABLE KEYS */;
INSERT INTO `profil_koni` VALUES (1,'Komite Olahraga Nasional Indonesia Kabupaten Klaten','KONI Klaten','Bersama membangun prestasi olahraga Kabupaten Klaten.','Komite Olahraga Nasional Indonesia (KONI) Kabupaten Klaten merupakan wadah koordinasi pembinaan dan pengembangan olahraga prestasi di tingkat kabupaten.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-11 06:31:00','2026-11-11 06:31:00');
/*!40000 ALTER TABLE `profil_koni` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publikasis`
--

DROP TABLE IF EXISTS `publikasis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publikasis` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_by` bigint unsigned DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `published_by` bigint unsigned DEFAULT NULL,
  `judul` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ringkasan` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `konten` longtext COLLATE utf8mb4_unicode_ci,
  `media_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `media_original_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thumbnail_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thumbnail_original_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `publikasis_slug_unique` (`slug`),
  KEY `publikasis_created_by_foreign` (`created_by`),
  KEY `publikasis_updated_by_foreign` (`updated_by`),
  KEY `publikasis_published_by_foreign` (`published_by`),
  KEY `publikasis_jenis_status_published_at_index` (`jenis`,`status`,`published_at`),
  KEY `publikasis_jenis_index` (`jenis`),
  KEY `publikasis_kategori_index` (`kategori`),
  KEY `publikasis_status_index` (`status`),
  CONSTRAINT `publikasis_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `publikasis_published_by_foreign` FOREIGN KEY (`published_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `publikasis_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publikasis`
--

LOCK TABLES `publikasis` WRITE;
/*!40000 ALTER TABLE `publikasis` DISABLE KEYS */;
/*!40000 ALTER TABLE `publikasis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'atlet_pelatih','web','2026-11-08 04:32:22','2026-11-08 04:32:22'),(2,'admin_cabor','web','2026-11-08 04:32:22','2026-11-08 04:32:22'),(3,'staff_koni','web','2026-11-08 04:32:22','2026-11-08 04:32:22'),(4,'admin_koni','web','2026-11-08 04:32:22','2026-11-08 04:32:22'),(5,'atlet','web','2026-11-08 08:55:31','2026-11-08 08:55:31'),(6,'pelatih','web','2026-11-08 08:55:31','2026-11-08 08:55:31'),(7,'ketua_koni','web','2026-11-19 18:27:49','2026-11-19 18:27:49'),(8,'sekretaris_koni','web','2026-11-19 18:27:49','2026-11-19 18:27:49');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('0vXmkjZOkn6Sg00U57SjvCUUKzrcdDI8rKV5UWPW',NULL,'172.18.0.1','curl/8.18.0','eyJfdG9rZW4iOiJsYVRYb1B2blFFQWJQM3FEOHBSb2NiTHBsUnc5bEJjYU9vUDhpNkt4IiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1795658983),('z9CIv5sAvkTmfezAesniLKm2OosTwU38vDBtbYH7',17,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJseWl6OUpwN2tTcGt2VG9kcGpKV29VYUhtbGw2S2pkQXpPV1c0Q1N0IiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cDpcL1wvbG9jYWxob3N0XC9hZG1pblwvY2Fib3IiLCJyb3V0ZSI6ImFkbWluLmNhYm9yLmluZGV4In0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoxNywicGFzc3dvcmRfaGFzaF93ZWIiOiIwZTc5MzM0ZmMzNjA1Yjc4YjAzM2E4OGMxNDliN2FmNzQ3ZDRiZWMzMjdjMWI2Y2YyYzdiMGRlOWQwYzIxYmNiIn0=',1795667136);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surat_activities`
--

DROP TABLE IF EXISTS `surat_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `surat_activities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `surat_id` bigint unsigned NOT NULL,
  `actor_id` bigint unsigned DEFAULT NULL,
  `action` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_from` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_to` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `surat_activities_actor_id_foreign` (`actor_id`),
  KEY `surat_activities_surat_id_created_at_index` (`surat_id`,`created_at`),
  CONSTRAINT `surat_activities_actor_id_foreign` FOREIGN KEY (`actor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `surat_activities_surat_id_foreign` FOREIGN KEY (`surat_id`) REFERENCES `surats` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surat_activities`
--

LOCK TABLES `surat_activities` WRITE;
/*!40000 ALTER TABLE `surat_activities` DISABLE KEYS */;
INSERT INTO `surat_activities` VALUES (1,1,9,'surat_dibuat',NULL,'draft','Surat dibuat sebagai draft.','2026-11-11 15:41:59','2026-11-11 15:41:59'),(2,1,9,'surat_diajukan','draft','diajukan','Surat diajukan kepada Staff KONI.','2026-11-11 15:42:07','2026-11-11 15:42:07'),(3,1,6,'surat_diteruskan_admin','diajukan','diteruskan_admin','Surat diteruskan kepada Admin KONI.','2026-11-11 15:42:33','2026-11-11 15:42:33'),(4,1,1,'keputusan_admin','diteruskan_admin','menunggu_penyampaian','Keputusan Admin KONI: diterima.','2026-11-11 15:43:01','2026-11-11 15:43:01'),(5,1,6,'hasil_disampaikan','menunggu_penyampaian','diterima','Staff KONI menyampaikan hasil keputusan kepada Admin Cabor.','2026-11-11 15:43:19','2026-11-11 15:43:19'),(6,2,9,'surat_dibuat',NULL,'draft','Surat dibuat sebagai draft.','2026-11-19 21:40:41','2026-11-19 21:40:41'),(7,2,9,'surat_diajukan','draft','diajukan','Surat diajukan kepada Staff KONI.','2026-11-19 21:40:47','2026-11-19 21:40:47'),(8,2,6,'surat_diteruskan_admin','diajukan','diteruskan_admin','Surat diteruskan kepada pimpinan KONI.','2026-11-19 21:41:08','2026-11-19 21:41:08');
/*!40000 ALTER TABLE `surat_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surat_messages`
--

DROP TABLE IF EXISTS `surat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `surat_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `surat_id` bigint unsigned NOT NULL,
  `sender_id` bigint unsigned DEFAULT NULL,
  `sender_role` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pesan',
  `body` text COLLATE utf8mb4_unicode_ci,
  `attachment_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_original_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `surat_messages_sender_id_foreign` (`sender_id`),
  KEY `surat_messages_surat_created_idx` (`surat_id`,`created_at`),
  CONSTRAINT `surat_messages_sender_id_foreign` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `surat_messages_surat_id_foreign` FOREIGN KEY (`surat_id`) REFERENCES `surats` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surat_messages`
--

LOCK TABLES `surat_messages` WRITE;
/*!40000 ALTER TABLE `surat_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `surat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surats`
--

DROP TABLE IF EXISTS `surats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `surats` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cabang_olahraga_id` bigint unsigned DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `staff_id` bigint unsigned DEFAULT NULL,
  `admin_koni_id` bigint unsigned DEFAULT NULL,
  `decision_by_role` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `perihal` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_surat` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'permohonan',
  `nomor_surat` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_surat` date NOT NULL,
  `ringkasan` text COLLATE utf8mb4_unicode_ci,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `staff_attachment_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `staff_attachment_original_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_response_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_response_original_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `keputusan_admin` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catatan_staff` text COLLATE utf8mb4_unicode_ci,
  `catatan_admin` text COLLATE utf8mb4_unicode_ci,
  `diajukan_at` timestamp NULL DEFAULT NULL,
  `diteruskan_at` timestamp NULL DEFAULT NULL,
  `diputuskan_at` timestamp NULL DEFAULT NULL,
  `disampaikan_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `surats_created_by_foreign` (`created_by`),
  KEY `surats_staff_id_foreign` (`staff_id`),
  KEY `surats_admin_koni_id_foreign` (`admin_koni_id`),
  KEY `surats_cabang_olahraga_id_status_index` (`cabang_olahraga_id`,`status`),
  KEY `surats_status_created_at_index` (`status`,`created_at`),
  KEY `surats_status_index` (`status`),
  CONSTRAINT `surats_admin_koni_id_foreign` FOREIGN KEY (`admin_koni_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `surats_cabang_olahraga_id_foreign` FOREIGN KEY (`cabang_olahraga_id`) REFERENCES `cabang_olahraga` (`id`) ON DELETE SET NULL,
  CONSTRAINT `surats_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `surats_staff_id_foreign` FOREIGN KEY (`staff_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surats`
--

LOCK TABLES `surats` WRITE;
/*!40000 ALTER TABLE `surats` DISABLE KEYS */;
INSERT INTO `surats` VALUES (1,3,9,6,1,NULL,'ajuan anggaran','permohonan',NULL,'2026-11-11','anggaran','surat/original/DsOXXrTnskdZO59Ebrj0BbZzQIMELDunEdi9u8ps.pdf','ToR Kegiatan Magang UMKLA.pdf',NULL,NULL,NULL,NULL,'diterima','diterima',NULL,NULL,'2026-11-11 15:42:07','2026-11-11 15:42:33','2026-11-11 15:43:01','2026-11-11 15:43:19','2026-11-11 15:41:59','2026-11-11 15:43:19'),(2,3,9,6,NULL,NULL,'gor','permohonan','12','2026-11-19','12','surat/original/QNlUtF0Kh3rGVgt2oocWWGfDKsGCz9m4LU9uCDkB.png','download.png',NULL,NULL,NULL,NULL,'diteruskan_admin',NULL,NULL,NULL,'2026-11-19 21:40:47','2026-11-19 21:41:08',NULL,NULL,'2026-11-19 21:40:41','2026-11-19 21:41:08');
/*!40000 ALTER TABLE `surats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template_surats`
--

DROP TABLE IF EXISTS `template_surats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `template_surats` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `judul` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploaded_by` bigint unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `template_surats_uploaded_by_foreign` (`uploaded_by`),
  KEY `template_surats_is_active_index` (`is_active`),
  CONSTRAINT `template_surats_uploaded_by_foreign` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_surats`
--

LOCK TABLES `template_surats` WRITE;
/*!40000 ALTER TABLE `template_surats` DISABLE KEYS */;
/*!40000 ALTER TABLE `template_surats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `must_change_password` tinyint(1) NOT NULL DEFAULT '0',
  `password_changed_at` timestamp NULL DEFAULT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cabang_olahraga_id` bigint unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_cabang_olahraga_id_foreign` (`cabang_olahraga_id`),
  CONSTRAINT `users_cabang_olahraga_id_foreign` FOREIGN KEY (`cabang_olahraga_id`) REFERENCES `cabang_olahraga` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrator KONI','admin@koniklaten.local',NULL,'$2y$12$B3XTS38gU7UXo9VjrqO5geCjL9U/iOtl7fgKe30uErBv3Aq..AEqi',0,NULL,NULL,NULL,NULL,'6bzcCp3al0aR09jWCBjLR9WvJieY43ReGBX3xawfeN3LIoOtAmlYlai1wfYp','2026-11-08 05:16:16','2026-11-08 05:16:16',NULL,1),(4,'Naila Fath','fath@contoh.com',NULL,'$2y$12$1o4O8xKRgiCdVub.XwKxf./9NofOg2QaoI.kNobFryURihl4z4ZfK',1,NULL,NULL,NULL,NULL,NULL,'2026-11-08 10:25:49','2026-11-08 10:25:49',NULL,1),(6,'staf koni','staf@koniklaten.id',NULL,'$2y$12$BBduhtJXFbf5j0.6NHb.t.4QgXZTRtUDWmn8bq6BT3E755q64u3m2',0,'2026-11-26 06:28:20',NULL,NULL,NULL,NULL,'2026-11-09 00:43:43','2026-11-26 06:28:21',NULL,1),(7,'kakanda','ffath@contoh.com',NULL,'$2y$12$Q.zKL5Upr2LIbCjlanL1ZeNLb2cR2Mh8CAHYLe.YYyISdxiYt0HxG',1,NULL,NULL,NULL,NULL,NULL,'2026-11-09 02:37:04','2026-11-09 02:37:04',2,1),(8,'kakanda','bulu@contoh.com',NULL,'$2y$12$lfK6PCUpdJ/C6hr8mpJkvu9q5hAmRgjdnLv87Eum3LFbkbYkiLklG',1,NULL,NULL,NULL,NULL,NULL,'2026-11-09 02:50:21','2026-11-09 02:50:21',NULL,1),(9,'charles','sepak@koniklaten.id',NULL,'$2y$12$CvFeXZPZv2IdeeO6mrMwrO0Gy800BXK8DqWikpbDsaeRcR1udQGKa',0,'2026-11-21 14:27:12',NULL,NULL,NULL,NULL,'2026-11-09 02:50:58','2026-11-21 14:27:13',3,1),(10,'charles','sepak1@koniklaten.id',NULL,'$2y$12$X/dklLsfcIKX/YOpGxuKMuZrALvyQ8VJyd4ehCYJfHXhhF8Q7suqm',0,'2026-11-21 14:28:31',NULL,NULL,NULL,NULL,'2026-11-09 02:53:03','2026-11-21 14:28:32',NULL,1),(11,'josh','sepak2@koniklaten.id',NULL,'$2y$12$bgywJjq1f8gwUbA4ipsfd.Gnnw2mm0f5UsPdGeCpmGMlNaR2HJqbq',0,'2026-11-21 14:29:20',NULL,NULL,NULL,NULL,'2026-11-09 02:53:36','2026-11-21 14:29:21',NULL,1),(12,'Mars','sepak4@koniklaten.id',NULL,'$2y$12$vgjbL6tctSK/I1BhMJqSLOuCfwt.vWwAZecIhNW13JLfLk5N44wYS',0,'2026-11-22 15:43:20',NULL,NULL,NULL,NULL,'2026-11-09 06:29:58','2026-11-22 15:43:20',NULL,1),(13,'DK','water@koniklaten.id',NULL,'$2y$12$LCck1gVYe7a.f8R9uZvvXesfeISh8BqnqMcOBlmf8MwTqejTdtT2S',1,NULL,NULL,NULL,NULL,NULL,'2026-11-11 16:37:19','2026-11-11 16:37:19',4,1),(14,'Jeonghan','water2@koniklaten.id',NULL,'$2y$12$Jx0kyt3cLOediRfTH3ZDSeA0qZKLb9RuNTDkzz1fIj/wIJll42C2a',0,'2026-11-22 15:00:21',NULL,NULL,NULL,NULL,'2026-11-11 16:42:12','2026-11-22 15:00:21',NULL,1),(15,'Wonu','water1@koniklaten.id',NULL,'$2y$12$zZ36mBb3c/ChiR865lm2b.tIyvQDdwaisGcgAQxq2B/RybpsWjKc.',1,NULL,NULL,NULL,NULL,NULL,'2026-11-11 16:44:53','2026-11-11 16:44:53',NULL,1),(16,'Mingyu','bend@koniklaten.id',NULL,'$2y$12$fslYhvInPetd4zLTM3o9xOgUd.IKruM1dMXEJVLHliwOM8QSnqwua',1,NULL,NULL,NULL,NULL,NULL,'2026-11-11 16:48:41','2026-11-11 16:48:41',NULL,1),(17,'Ketua KONI','ketua@koniklaten.id',NULL,'$2y$12$W0NI8b5skZr.hWUyuWvUsetcV87PXXgWG6.ayy2DWMoUtFeBgFpXa',0,NULL,NULL,NULL,NULL,NULL,'2026-11-19 18:43:34','2026-11-19 18:43:34',NULL,1),(18,'Sekertaris KONI','sekertaris@koniklaten.id',NULL,'$2y$12$okjutE8/mjMRAsM1Fiz.TORL6hvwNoQFw.nNXISrmDYjcWQt3lrqy',0,NULL,NULL,NULL,NULL,NULL,'2026-11-19 18:44:16','2026-11-19 18:44:16',NULL,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website_appearance_settings`
--

DROP TABLE IF EXISTS `website_appearance_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `website_appearance_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `draft_config` json NOT NULL,
  `published_config` json NOT NULL,
  `published_at` datetime DEFAULT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `website_appearance_settings_updated_by_foreign` (`updated_by`),
  CONSTRAINT `website_appearance_settings_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website_appearance_settings`
--

LOCK TABLES `website_appearance_settings` WRITE;
/*!40000 ALTER TABLE `website_appearance_settings` DISABLE KEYS */;
INSERT INTO `website_appearance_settings` VALUES (1,'{\"pages\": {\"home\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"Bersama membangun prestasi olahraga Kabupaten Klaten.\", \"eyebrow\": \"KOMITE OLAHRAGA NASIONAL INDONESIA\", \"visible\": true, \"card_title\": \"KONI Klaten\", \"description\": \"Satu portal informasi untuk mengenal cabang olahraga, atlet, pelatih, dan kepengurusan KONI Kabupaten Klaten.\", \"button_label\": \"Jelajahi Cabang Olahraga\", \"card_eyebrow\": \"PORTAL OLAHRAGA\", \"button_target\": \"cabor\", \"card_cabor_label\": \"Cabang olahraga\", \"card_coach_label\": \"Pelatih aktif\", \"card_footer_text\": \"Kenali potensi dan ekosistem olahraga Klaten.\", \"card_athlete_label\": \"Atlet aktif\", \"card_footer_eyebrow\": \"SATU WADAH INFORMASI\", \"card_management_label\": \"Pengurus KONI\", \"secondary_button_label\": \"Tentang KONI\", \"secondary_button_target\": \"about\"}, \"about\": {\"order\": 30, \"title\": \"Mengenal organisasi KONI\", \"eyebrow\": \"TENTANG ORGANISASI\", \"visible\": true, \"description\": \"\", \"button_label\": \"Lihat struktur pengurus\", \"closing_text\": \"Melalui portal ini, masyarakat dapat mengenal cabang olahraga, melihat informasi atlet dan pelatih yang terdaftar, serta mengetahui susunan pengurus organisasi.\", \"vision_label\": \"Visi\", \"button_target\": \"struktur\", \"history_label\": \"Sejarah\", \"mission_label\": \"Misi\"}, \"stats\": {\"order\": 20, \"title\": \"\", \"eyebrow\": \"\", \"visible\": true, \"cabor_label\": \"Cabang olahraga\", \"coach_label\": \"Pelatih aktif\", \"description\": \"\", \"medal_label\": \"Medali terdata\", \"athlete_label\": \"Atlet aktif\", \"management_label\": \"Pengurus KONI\", \"achievement_label\": \"Prestasi terverifikasi\"}, \"member_cta\": {\"order\": 100, \"title\": \"Atlet, pelatih, dan pengelola cabor\", \"eyebrow\": \"PORTAL ANGGOTA\", \"visible\": true, \"description\": \"Masuk ke portal anggota untuk mengakses layanan sesuai hak akses akun.\", \"button_label\": \"Masuk Portal Anggota\", \"button_target\": \"login\"}, \"news_preview\": {\"order\": 80, \"title\": \"Berita KONI Klaten\", \"eyebrow\": \"KABAR TERBARU\", \"visible\": true, \"description\": \"Informasi dan perkembangan olahraga Kabupaten Klaten.\", \"button_label\": \"Semua berita\", \"button_target\": \"berita\"}, \"cabor_preview\": {\"order\": 40, \"title\": \"Cabang olahraga\", \"eyebrow\": \"EKOSISTEM OLAHRAGA\", \"visible\": true, \"description\": \"Jelajahi cabang olahraga yang terdaftar di KONI Kabupaten Klaten.\", \"button_label\": \"Lihat semua cabor\", \"button_target\": \"cabor\"}, \"agenda_preview\": {\"order\": 70, \"title\": \"Agenda & kejuaraan mendatang\", \"eyebrow\": \"KALENDER OLAHRAGA\", \"visible\": true, \"description\": \"Informasi kegiatan dan kejuaraan yang telah dipublikasikan oleh pengelola KONI Klaten.\", \"button_label\": \"Lihat semua agenda\", \"button_target\": \"agenda\"}, \"management_preview\": {\"order\": 50, \"title\": \"Pengurus KONI Klaten\", \"eyebrow\": \"KEPENGURUSAN\", \"visible\": true, \"description\": \"Susunan pengurus tingkat kabupaten yang tercatat dalam sistem.\", \"button_label\": \"Lihat struktur pengurus\", \"button_target\": \"struktur\"}, \"achievements_preview\": {\"order\": 60, \"title\": \"Prestasi terverifikasi\", \"eyebrow\": \"CAPAIAN OLAHRAGA\", \"visible\": true, \"description\": \"Capaian atlet dan pelatih yang telah diverifikasi oleh Admin Cabor.\", \"button_label\": \"Lihat statistik lengkap\", \"button_target\": \"statistik\"}, \"documentation_preview\": {\"order\": 90, \"title\": \"Dokumentasi olahraga\", \"eyebrow\": \"GALERI KEGIATAN\", \"visible\": true, \"description\": \"Foto dan video kegiatan KONI Kabupaten Klaten.\", \"button_label\": \"Lihat semua dokumentasi\", \"button_target\": \"dokumentasi\"}}, \"title_color\": \"#ffffff\", \"accent_color\": \"#d71920\", \"backdrop_path\": \"website-backdrops/home/4kOxRzBXXYuoIkpjrWra08r0eqjHDGvlG8pKqLqG.jpg\", \"eyebrow_color\": \"#fca5a5\", \"overlay_opacity\": \"62\", \"button_background\": \"#d71920\", \"button_text_color\": \"#ffffff\", \"description_color\": \"#cbd5e1\", \"section_text_color\": \"#64748b\", \"background_position\": \"center\", \"hero_background_color\": \"#17191f\", \"section_heading_color\": \"#0f172a\", \"section_background_color\": \"#ffffff\"}, \"cabor\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"Cabang Olahraga\", \"eyebrow\": \"DIREKTORI OLAHRAGA\", \"visible\": true, \"description\": \"Temukan cabang olahraga, informasi atlet, pelatih, dan struktur pengurus pada masing-masing cabang.\"}, \"results\": {\"order\": 20, \"title\": \"Daftar cabang olahraga\", \"eyebrow\": \"DIREKTORI KONI\", \"visible\": true, \"count_label\": \"cabang olahraga\", \"description\": \"Pilih cabang olahraga untuk melihat informasi atlet, pelatih, prestasi, dan kepengurusannya.\", \"reset_label\": \"Reset\", \"button_label\": \"Cari Cabor\", \"detail_link_label\": \"Lihat detail cabang olahraga\", \"search_placeholder\": \"Cari nama atau singkatan cabang olahraga...\"}}, \"title_color\": \"#ffffff\", \"accent_color\": \"#d71920\", \"backdrop_path\": \"website-backdrops/cabor/LL2Q0xejdVLq4uex44kbSNZmNPheEDCosLO1zBav.webp\", \"eyebrow_color\": \"#fca5a5\", \"overlay_opacity\": \"60\", \"button_background\": \"#d71920\", \"button_text_color\": \"#ffffff\", \"description_color\": \"#cbd5e1\", \"section_text_color\": \"#64748b\", \"background_position\": \"right\", \"hero_background_color\": \"#17191f\", \"section_heading_color\": \"#0f172a\", \"section_background_color\": \"#ffffff\"}, \"agenda\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"Agenda & Kejuaraan\", \"eyebrow\": \"INFORMASI OLAHRAGA\", \"visible\": true, \"description\": \"Ikuti kegiatan, agenda organisasi, dan kejuaraan olahraga KONI Kabupaten Klaten.\"}, \"filters\": {\"order\": 20, \"title\": \"Temukan agenda\", \"eyebrow\": \"\", \"visible\": true, \"description\": \"\", \"button_label\": \"Cari agenda\", \"search_placeholder\": \"Cari agenda, lokasi, atau cabor...\"}, \"listing\": {\"order\": 30, \"title\": \"Agenda dan kejuaraan\", \"eyebrow\": \"KALENDER OLAHRAGA\", \"visible\": true, \"description\": \"Jadwal kegiatan dan kejuaraan yang telah dipublikasikan oleh KONI Kabupaten Klaten.\", \"detail_link_label\": \"Selengkapnya\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"berita\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"Berita KONI Klaten\", \"eyebrow\": \"KABAR OLAHRAGA KLATEN\", \"visible\": true, \"description\": \"Informasi, kabar kegiatan, dan perkembangan olahraga Kabupaten Klaten.\"}, \"filters\": {\"order\": 20, \"title\": \"Temukan berita\", \"eyebrow\": \"\", \"visible\": true, \"description\": \"\", \"button_label\": \"Cari berita\", \"search_placeholder\": \"Cari berita...\"}, \"listing\": {\"order\": 30, \"title\": \"Berita terbaru\", \"eyebrow\": \"PUBLIKASI KONI\", \"visible\": true, \"description\": \"Informasi dan perkembangan olahraga Kabupaten Klaten.\", \"detail_link_label\": \"Baca selengkapnya\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"struktur\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"Struktur Pengurus KONI Klaten\", \"eyebrow\": \"ORGANISASI\", \"visible\": true, \"description\": \"Informasi susunan pengurus tingkat Kabupaten Klaten yang tercatat dan berstatus aktif.\"}, \"directory\": {\"order\": 20, \"title\": \"Daftar pengurus aktif\", \"eyebrow\": \"KEPENGURUSAN KONI\", \"visible\": true, \"description\": \"Susunan pengurus yang tercatat dan berstatus aktif.\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"statistik\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"Statistik Prestasi KONI Klaten\", \"eyebrow\": \"DATA DAN CAPAIAN OLAHRAGA\", \"visible\": true, \"description\": \"Ringkasan data cabang olahraga, atlet, pelatih, dan prestasi terverifikasi.\", \"reset_label\": \"Reset\", \"button_label\": \"Terapkan filter tahun\", \"filter_label\": \"Filter tahun kejuaraan\", \"all_years_text\": \"Menampilkan seluruh tahun yang tercatat.\", \"selected_year_prefix\": \"Menampilkan data tahun\"}, \"levels\": {\"order\": 50, \"title\": \"Sebaran prestasi\", \"eyebrow\": \"TINGKAT KEJUARAAN\", \"visible\": true, \"description\": \"\"}, \"medals\": {\"order\": 30, \"title\": \"Medali yang tercatat\", \"eyebrow\": \"PEROLEHAN MEDALI\", \"visible\": true, \"gold_label\": \"Emas\", \"description\": \"Medali dihitung berdasarkan jenis medali yang dipilih saat prestasi diunggah. Prestasi lama tanpa klasifikasi medali tetap masuk total prestasi, tetapi tidak ditambahkan ke hitungan medali.\", \"bronze_label\": \"Perunggu\", \"silver_label\": \"Perak\"}, \"recent\": {\"order\": 70, \"title\": \"Prestasi terbaru\", \"eyebrow\": \"CATATAN PRESTASI\", \"visible\": true, \"description\": \"\"}, \"trends\": {\"order\": 40, \"title\": \"Perkembangan lima tahun\", \"eyebrow\": \"TREN PRESTASI\", \"visible\": true, \"description\": \"Jumlah prestasi terverifikasi per tahun, dari cabang olahraga aktif. Grafik ini tetap menampilkan lima tahun terakhir meskipun filter tahun dipilih.\"}, \"ranking\": {\"order\": 60, \"title\": \"Capaian berdasarkan cabor\", \"eyebrow\": \"PERINGKAT CABANG OLAHRAGA\", \"visible\": true, \"description\": \"Diurutkan berdasarkan jumlah prestasi terverifikasi, kemudian perolehan medali.\", \"achievement_label\": \"prestasi\"}, \"overview\": {\"order\": 20, \"title\": \"Gambaran olahraga Klaten\", \"eyebrow\": \"RINGKASAN\", \"visible\": true, \"cabor_label\": \"Cabang olahraga aktif\", \"coach_label\": \"Pelatih aktif\", \"description\": \"\", \"athlete_label\": \"Atlet aktif\", \"achievement_label\": \"Prestasi terverifikasi\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"dokumentasi\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"Dokumentasi\", \"eyebrow\": \"GALERI KEGIATAN\", \"visible\": true, \"description\": \"Foto dan video kegiatan olahraga, kejuaraan, serta aktivitas KONI Kabupaten Klaten.\"}, \"filters\": {\"order\": 20, \"title\": \"Temukan dokumentasi\", \"eyebrow\": \"\", \"visible\": true, \"description\": \"\", \"button_label\": \"Cari dokumentasi\", \"search_placeholder\": \"Cari dokumentasi...\"}, \"gallery\": {\"order\": 30, \"title\": \"Galeri dokumentasi\", \"eyebrow\": \"ARSIP KEGIATAN\", \"visible\": true, \"description\": \"Dokumentasi foto dan video kegiatan KONI Kabupaten Klaten.\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"cabor_detail\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"\", \"eyebrow\": \"PROFIL CABANG OLAHRAGA\", \"visible\": true, \"description\": \"\", \"button_label\": \"Semua Cabang Olahraga\", \"button_target\": \"cabor\"}, \"coaches\": {\"order\": 40, \"title\": \"Pelatih aktif\", \"eyebrow\": \"TENAGA PEMBINAAN\", \"visible\": true, \"description\": \"\"}, \"athletes\": {\"order\": 20, \"title\": \"Atlet aktif\", \"eyebrow\": \"SUMBER DAYA ATLET\", \"visible\": true, \"description\": \"\"}, \"management\": {\"order\": 50, \"title\": \"Struktur pengurus cabor\", \"eyebrow\": \"ORGANISASI CABANG\", \"visible\": true, \"description\": \"\"}, \"achievements\": {\"order\": 30, \"title\": \"Prestasi atlet dan pelatih terverifikasi\", \"eyebrow\": \"CAPAIAN OLAHRAGA\", \"visible\": true, \"description\": \"\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"agenda_detail\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"\", \"eyebrow\": \"AGENDA DAN KEJUARAAN\", \"visible\": true, \"description\": \"\", \"button_label\": \"Kembali ke Agenda\", \"button_target\": \"agenda\"}, \"details\": {\"order\": 20, \"title\": \"Informasi kegiatan\", \"eyebrow\": \"INFORMASI KEGIATAN\", \"visible\": true, \"description\": \"\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"berita_detail\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"\", \"eyebrow\": \"BERITA KONI\", \"visible\": true, \"description\": \"\", \"button_label\": \"Kembali ke Berita\", \"button_target\": \"berita\"}, \"article\": {\"order\": 20, \"title\": \"Informasi berita\", \"eyebrow\": \"PUBLIKASI\", \"visible\": true, \"description\": \"\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"dokumentasi_detail\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"\", \"eyebrow\": \"DOKUMENTASI KONI\", \"visible\": true, \"description\": \"\", \"button_label\": \"Kembali ke Dokumentasi\", \"button_target\": \"dokumentasi\"}, \"media\": {\"order\": 20, \"title\": \"Dokumentasi kegiatan\", \"eyebrow\": \"ARSIP KEGIATAN\", \"visible\": true, \"description\": \"\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}}, \"font_family\": \"figtree\", \"primary_color\": \"#d71920\", \"global_content\": {\"nav_home\": \"Beranda\", \"nav_news\": \"Berita\", \"nav_cabor\": \"Cabang Olahraga\", \"nav_agenda\": \"Agenda & Kejuaraan\", \"nav_profile\": \"Profil KONI\", \"footer_bottom\": \"Portal Informasi dan Manajemen Olahraga\", \"footer_portal\": \"Login Portal Anggota\", \"nav_structure\": \"Struktur Pengurus\", \"portal_button\": \"Portal Anggota\", \"footer_heading\": \"Jelajahi\", \"nav_statistics\": \"Statistik Prestasi\", \"nav_documentation\": \"Dokumentasi\", \"footer_description\": null}, \"secondary_color\": \"#17191f\", \"footer_background\": \"#17191f\", \"header_background\": \"#ffffff\"}','{\"pages\": {\"home\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"Bersama membangun prestasi olahraga Kabupaten Klaten.\", \"eyebrow\": \"KOMITE OLAHRAGA NASIONAL INDONESIA\", \"visible\": true, \"card_title\": \"KONI Klaten\", \"description\": \"Satu portal informasi untuk mengenal cabang olahraga, atlet, pelatih, dan kepengurusan KONI Kabupaten Klaten.\", \"button_label\": \"Jelajahi Cabang Olahraga\", \"card_eyebrow\": \"PORTAL OLAHRAGA\", \"button_target\": \"cabor\", \"card_cabor_label\": \"Cabang olahraga\", \"card_coach_label\": \"Pelatih aktif\", \"card_footer_text\": \"Kenali potensi dan ekosistem olahraga Klaten.\", \"card_athlete_label\": \"Atlet aktif\", \"card_footer_eyebrow\": \"SATU WADAH INFORMASI\", \"card_management_label\": \"Pengurus KONI\", \"secondary_button_label\": \"Tentang KONI\", \"secondary_button_target\": \"about\"}, \"about\": {\"order\": 30, \"title\": \"Mengenal organisasi KONI\", \"eyebrow\": \"TENTANG ORGANISASI\", \"visible\": true, \"description\": \"\", \"button_label\": \"Lihat struktur pengurus\", \"closing_text\": \"Melalui portal ini, masyarakat dapat mengenal cabang olahraga, melihat informasi atlet dan pelatih yang terdaftar, serta mengetahui susunan pengurus organisasi.\", \"vision_label\": \"Visi\", \"button_target\": \"struktur\", \"history_label\": \"Sejarah\", \"mission_label\": \"Misi\"}, \"stats\": {\"order\": 20, \"title\": \"\", \"eyebrow\": \"\", \"visible\": true, \"cabor_label\": \"Cabang olahraga\", \"coach_label\": \"Pelatih aktif\", \"description\": \"\", \"medal_label\": \"Medali terdata\", \"athlete_label\": \"Atlet aktif\", \"management_label\": \"Pengurus KONI\", \"achievement_label\": \"Prestasi terverifikasi\"}, \"member_cta\": {\"order\": 100, \"title\": \"Atlet, pelatih, dan pengelola cabor\", \"eyebrow\": \"PORTAL ANGGOTA\", \"visible\": true, \"description\": \"Masuk ke portal anggota untuk mengakses layanan sesuai hak akses akun.\", \"button_label\": \"Masuk Portal Anggota\", \"button_target\": \"login\"}, \"news_preview\": {\"order\": 80, \"title\": \"Berita KONI Klaten\", \"eyebrow\": \"KABAR TERBARU\", \"visible\": true, \"description\": \"Informasi dan perkembangan olahraga Kabupaten Klaten.\", \"button_label\": \"Semua berita\", \"button_target\": \"berita\"}, \"cabor_preview\": {\"order\": 40, \"title\": \"Cabang olahraga\", \"eyebrow\": \"EKOSISTEM OLAHRAGA\", \"visible\": true, \"description\": \"Jelajahi cabang olahraga yang terdaftar di KONI Kabupaten Klaten.\", \"button_label\": \"Lihat semua cabor\", \"button_target\": \"cabor\"}, \"agenda_preview\": {\"order\": 70, \"title\": \"Agenda & kejuaraan mendatang\", \"eyebrow\": \"KALENDER OLAHRAGA\", \"visible\": true, \"description\": \"Informasi kegiatan dan kejuaraan yang telah dipublikasikan oleh pengelola KONI Klaten.\", \"button_label\": \"Lihat semua agenda\", \"button_target\": \"agenda\"}, \"management_preview\": {\"order\": 50, \"title\": \"Pengurus KONI Klaten\", \"eyebrow\": \"KEPENGURUSAN\", \"visible\": true, \"description\": \"Susunan pengurus tingkat kabupaten yang tercatat dalam sistem.\", \"button_label\": \"Lihat struktur pengurus\", \"button_target\": \"struktur\"}, \"achievements_preview\": {\"order\": 60, \"title\": \"Prestasi terverifikasi\", \"eyebrow\": \"CAPAIAN OLAHRAGA\", \"visible\": true, \"description\": \"Capaian atlet dan pelatih yang telah diverifikasi oleh Admin Cabor.\", \"button_label\": \"Lihat statistik lengkap\", \"button_target\": \"statistik\"}, \"documentation_preview\": {\"order\": 90, \"title\": \"Dokumentasi olahraga\", \"eyebrow\": \"GALERI KEGIATAN\", \"visible\": true, \"description\": \"Foto dan video kegiatan KONI Kabupaten Klaten.\", \"button_label\": \"Lihat semua dokumentasi\", \"button_target\": \"dokumentasi\"}}, \"title_color\": \"#ffffff\", \"accent_color\": \"#d71920\", \"backdrop_path\": \"website-backdrops/home/4kOxRzBXXYuoIkpjrWra08r0eqjHDGvlG8pKqLqG.jpg\", \"eyebrow_color\": \"#fca5a5\", \"overlay_opacity\": \"62\", \"button_background\": \"#d71920\", \"button_text_color\": \"#ffffff\", \"description_color\": \"#cbd5e1\", \"section_text_color\": \"#64748b\", \"background_position\": \"center\", \"hero_background_color\": \"#17191f\", \"section_heading_color\": \"#0f172a\", \"section_background_color\": \"#ffffff\"}, \"cabor\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"Cabang Olahraga\", \"eyebrow\": \"DIREKTORI OLAHRAGA\", \"visible\": true, \"description\": \"Temukan cabang olahraga, informasi atlet, pelatih, dan struktur pengurus pada masing-masing cabang.\"}, \"results\": {\"order\": 20, \"title\": \"Daftar cabang olahraga\", \"eyebrow\": \"DIREKTORI KONI\", \"visible\": true, \"count_label\": \"cabang olahraga\", \"description\": \"Pilih cabang olahraga untuk melihat informasi atlet, pelatih, prestasi, dan kepengurusannya.\", \"reset_label\": \"Reset\", \"button_label\": \"Cari Cabor\", \"detail_link_label\": \"Lihat detail cabang olahraga\", \"search_placeholder\": \"Cari nama atau singkatan cabang olahraga...\"}}, \"title_color\": \"#ffffff\", \"accent_color\": \"#d71920\", \"backdrop_path\": \"website-backdrops/cabor/LL2Q0xejdVLq4uex44kbSNZmNPheEDCosLO1zBav.webp\", \"eyebrow_color\": \"#fca5a5\", \"overlay_opacity\": \"60\", \"button_background\": \"#d71920\", \"button_text_color\": \"#ffffff\", \"description_color\": \"#cbd5e1\", \"section_text_color\": \"#64748b\", \"background_position\": \"right\", \"hero_background_color\": \"#17191f\", \"section_heading_color\": \"#0f172a\", \"section_background_color\": \"#ffffff\"}, \"agenda\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"Agenda & Kejuaraan\", \"eyebrow\": \"INFORMASI OLAHRAGA\", \"visible\": true, \"description\": \"Ikuti kegiatan, agenda organisasi, dan kejuaraan olahraga KONI Kabupaten Klaten.\"}, \"filters\": {\"order\": 20, \"title\": \"Temukan agenda\", \"eyebrow\": \"\", \"visible\": true, \"description\": \"\", \"button_label\": \"Cari agenda\", \"search_placeholder\": \"Cari agenda, lokasi, atau cabor...\"}, \"listing\": {\"order\": 30, \"title\": \"Agenda dan kejuaraan\", \"eyebrow\": \"KALENDER OLAHRAGA\", \"visible\": true, \"description\": \"Jadwal kegiatan dan kejuaraan yang telah dipublikasikan oleh KONI Kabupaten Klaten.\", \"detail_link_label\": \"Selengkapnya\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"berita\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"Berita KONI Klaten\", \"eyebrow\": \"KABAR OLAHRAGA KLATEN\", \"visible\": true, \"description\": \"Informasi, kabar kegiatan, dan perkembangan olahraga Kabupaten Klaten.\"}, \"filters\": {\"order\": 20, \"title\": \"Temukan berita\", \"eyebrow\": \"\", \"visible\": true, \"description\": \"\", \"button_label\": \"Cari berita\", \"search_placeholder\": \"Cari berita...\"}, \"listing\": {\"order\": 30, \"title\": \"Berita terbaru\", \"eyebrow\": \"PUBLIKASI KONI\", \"visible\": true, \"description\": \"Informasi dan perkembangan olahraga Kabupaten Klaten.\", \"detail_link_label\": \"Baca selengkapnya\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"struktur\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"Struktur Pengurus KONI Klaten\", \"eyebrow\": \"ORGANISASI\", \"visible\": true, \"description\": \"Informasi susunan pengurus tingkat Kabupaten Klaten yang tercatat dan berstatus aktif.\"}, \"directory\": {\"order\": 20, \"title\": \"Daftar pengurus aktif\", \"eyebrow\": \"KEPENGURUSAN KONI\", \"visible\": true, \"description\": \"Susunan pengurus yang tercatat dan berstatus aktif.\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"statistik\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"Statistik Prestasi KONI Klaten\", \"eyebrow\": \"DATA DAN CAPAIAN OLAHRAGA\", \"visible\": true, \"description\": \"Ringkasan data cabang olahraga, atlet, pelatih, dan prestasi terverifikasi.\", \"reset_label\": \"Reset\", \"button_label\": \"Terapkan filter tahun\", \"filter_label\": \"Filter tahun kejuaraan\", \"all_years_text\": \"Menampilkan seluruh tahun yang tercatat.\", \"selected_year_prefix\": \"Menampilkan data tahun\"}, \"levels\": {\"order\": 50, \"title\": \"Sebaran prestasi\", \"eyebrow\": \"TINGKAT KEJUARAAN\", \"visible\": true, \"description\": \"\"}, \"medals\": {\"order\": 30, \"title\": \"Medali yang tercatat\", \"eyebrow\": \"PEROLEHAN MEDALI\", \"visible\": true, \"gold_label\": \"Emas\", \"description\": \"Medali dihitung berdasarkan jenis medali yang dipilih saat prestasi diunggah. Prestasi lama tanpa klasifikasi medali tetap masuk total prestasi, tetapi tidak ditambahkan ke hitungan medali.\", \"bronze_label\": \"Perunggu\", \"silver_label\": \"Perak\"}, \"recent\": {\"order\": 70, \"title\": \"Prestasi terbaru\", \"eyebrow\": \"CATATAN PRESTASI\", \"visible\": true, \"description\": \"\"}, \"trends\": {\"order\": 40, \"title\": \"Perkembangan lima tahun\", \"eyebrow\": \"TREN PRESTASI\", \"visible\": true, \"description\": \"Jumlah prestasi terverifikasi per tahun, dari cabang olahraga aktif. Grafik ini tetap menampilkan lima tahun terakhir meskipun filter tahun dipilih.\"}, \"ranking\": {\"order\": 60, \"title\": \"Capaian berdasarkan cabor\", \"eyebrow\": \"PERINGKAT CABANG OLAHRAGA\", \"visible\": true, \"description\": \"Diurutkan berdasarkan jumlah prestasi terverifikasi, kemudian perolehan medali.\", \"achievement_label\": \"prestasi\"}, \"overview\": {\"order\": 20, \"title\": \"Gambaran olahraga Klaten\", \"eyebrow\": \"RINGKASAN\", \"visible\": true, \"cabor_label\": \"Cabang olahraga aktif\", \"coach_label\": \"Pelatih aktif\", \"description\": \"\", \"athlete_label\": \"Atlet aktif\", \"achievement_label\": \"Prestasi terverifikasi\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"dokumentasi\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"Dokumentasi\", \"eyebrow\": \"GALERI KEGIATAN\", \"visible\": true, \"description\": \"Foto dan video kegiatan olahraga, kejuaraan, serta aktivitas KONI Kabupaten Klaten.\"}, \"filters\": {\"order\": 20, \"title\": \"Temukan dokumentasi\", \"eyebrow\": \"\", \"visible\": true, \"description\": \"\", \"button_label\": \"Cari dokumentasi\", \"search_placeholder\": \"Cari dokumentasi...\"}, \"gallery\": {\"order\": 30, \"title\": \"Galeri dokumentasi\", \"eyebrow\": \"ARSIP KEGIATAN\", \"visible\": true, \"description\": \"Dokumentasi foto dan video kegiatan KONI Kabupaten Klaten.\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"cabor_detail\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"\", \"eyebrow\": \"PROFIL CABANG OLAHRAGA\", \"visible\": true, \"description\": \"\", \"button_label\": \"Semua Cabang Olahraga\", \"button_target\": \"cabor\"}, \"coaches\": {\"order\": 40, \"title\": \"Pelatih aktif\", \"eyebrow\": \"TENAGA PEMBINAAN\", \"visible\": true, \"description\": \"\"}, \"athletes\": {\"order\": 20, \"title\": \"Atlet aktif\", \"eyebrow\": \"SUMBER DAYA ATLET\", \"visible\": true, \"description\": \"\"}, \"management\": {\"order\": 50, \"title\": \"Struktur pengurus cabor\", \"eyebrow\": \"ORGANISASI CABANG\", \"visible\": true, \"description\": \"\"}, \"achievements\": {\"order\": 30, \"title\": \"Prestasi atlet dan pelatih terverifikasi\", \"eyebrow\": \"CAPAIAN OLAHRAGA\", \"visible\": true, \"description\": \"\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"agenda_detail\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"\", \"eyebrow\": \"AGENDA DAN KEJUARAAN\", \"visible\": true, \"description\": \"\", \"button_label\": \"Kembali ke Agenda\", \"button_target\": \"agenda\"}, \"details\": {\"order\": 20, \"title\": \"Informasi kegiatan\", \"eyebrow\": \"INFORMASI KEGIATAN\", \"visible\": true, \"description\": \"\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"berita_detail\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"\", \"eyebrow\": \"BERITA KONI\", \"visible\": true, \"description\": \"\", \"button_label\": \"Kembali ke Berita\", \"button_target\": \"berita\"}, \"article\": {\"order\": 20, \"title\": \"Informasi berita\", \"eyebrow\": \"PUBLIKASI\", \"visible\": true, \"description\": \"\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}, \"dokumentasi_detail\": {\"sections\": {\"hero\": {\"order\": 10, \"title\": \"\", \"eyebrow\": \"DOKUMENTASI KONI\", \"visible\": true, \"description\": \"\", \"button_label\": \"Kembali ke Dokumentasi\", \"button_target\": \"dokumentasi\"}, \"media\": {\"order\": 20, \"title\": \"Dokumentasi kegiatan\", \"eyebrow\": \"ARSIP KEGIATAN\", \"visible\": true, \"description\": \"\"}}, \"title_color\": \"#FFFFFF\", \"accent_color\": \"#D71920\", \"backdrop_path\": null, \"eyebrow_color\": \"#FCA5A5\", \"overlay_opacity\": 62, \"button_background\": \"#D71920\", \"button_text_color\": \"#FFFFFF\", \"description_color\": \"#CBD5E1\", \"section_text_color\": \"#64748B\", \"background_position\": \"center\", \"hero_background_color\": \"#17191F\", \"section_heading_color\": \"#0F172A\", \"section_background_color\": \"#FFFFFF\"}}, \"font_family\": \"figtree\", \"primary_color\": \"#d71920\", \"global_content\": {\"nav_home\": \"Beranda\", \"nav_news\": \"Berita\", \"nav_cabor\": \"Cabang Olahraga\", \"nav_agenda\": \"Agenda & Kejuaraan\", \"nav_profile\": \"Profil KONI\", \"footer_bottom\": \"Portal Informasi dan Manajemen Olahraga\", \"footer_portal\": \"Login Portal Anggota\", \"nav_structure\": \"Struktur Pengurus\", \"portal_button\": \"Portal Anggota\", \"footer_heading\": \"Jelajahi\", \"nav_statistics\": \"Statistik Prestasi\", \"nav_documentation\": \"Dokumentasi\", \"footer_description\": null}, \"secondary_color\": \"#17191f\", \"footer_background\": \"#17191f\", \"header_background\": \"#ffffff\"}','2026-11-26 08:04:14',1,'2026-11-21 21:29:25','2026-11-26 08:04:14');
/*!40000 ALTER TABLE `website_appearance_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'laravel'
--

--
-- Dumping routines for database 'laravel'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-26  5:11:55
