<?php

namespace App\Providers;

use App\Models\ProfilKoni;
use App\Models\InventoryCategory;
use App\Models\InventoryItem;
use App\Policies\InventoryCategoryPolicy;
use App\Policies\InventoryItemPolicy;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        Gate::policy(InventoryItem::class, InventoryItemPolicy::class);
        Gate::policy(InventoryCategory::class, InventoryCategoryPolicy::class);

        View::composer('layouts.public', function ($view): void {
            $view->with('profilKoni', ProfilKoni::query()->first());
        });
    }
}
