<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Database backup configuration
    |--------------------------------------------------------------------------
    |
    | Backup files are stored in Laravel's private application storage.
    | Never point this directory to public/ or public/storage/.
    |
    */

    'directory' => storage_path('app/private/backups'),

    // Null means use DB_CONNECTION from the main database configuration.
    'connection' => env('KONI_BACKUP_CONNECTION'),

    'retention_days' => (int) env('KONI_BACKUP_RETENTION_DAYS', 30),

    'schedule_time' => env('KONI_BACKUP_SCHEDULE_TIME', '02:00'),

    'process_timeout' => (int) env('KONI_BACKUP_PROCESS_TIMEOUT', 1800),

    'mysqldump_binary' => env('KONI_MYSQLDUMP_BINARY', 'mysqldump'),

    'mysql_binary' => env('KONI_MYSQL_BINARY', 'mysql'),
];
