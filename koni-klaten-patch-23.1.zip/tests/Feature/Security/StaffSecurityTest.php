<?php

namespace Tests\Feature\Security;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Route;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class StaffSecurityTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $roles = [
            'admin_koni',
            'ketua_koni',
            'sekretaris_koni',
            'staff_koni',
            'admin_cabor',
            'atlet',
            'pelatih',
            'atlet_pelatih',
        ];

        foreach ($roles as $role) {
            Role::firstOrCreate([
                'name' => $role,
                'guard_name' => 'web',
            ]);
        }

        app(PermissionRegistrar::class)
            ->forgetCachedPermissions();
    }

    /**
     * Membuat akun dengan role tertentu.
     */
    private function createUserWithRole(string $role): User
    {
        $user = User::factory()->create([
            'is_active' => true,
        ]);

        $user->assignRole($role);

        return $user;
    }

    /**
     * Staff dapat membuka data master read-only dan modul operasional yang dikelolanya.
     */
    public function test_staff_can_access_all_read_only_pages(): void
    {
        $staff = $this->createUserWithRole('staff_koni');

        $this->actingAs($staff);

        $routes = [
            'dashboard.staff-koni',
            'staff.cabor.index',
            'staff.atlet.index',
            'staff.pelatih.index',
            'staff.pengurus.index',
            'staff.agenda.index',
            'staff.surat.index',
            'staff.templates.index',
            'staff.publikasi.index',
        ];

        foreach ($routes as $routeName) {
            $response = $this->get(route($routeName));

            $response->assertOk();
        }
    }

    /**
     * Staff tidak boleh membuka panel Admin KONI
     * maupun Admin Cabor.
     */
    public function test_staff_cannot_access_admin_panels(): void
    {
        $staff = $this->createUserWithRole('staff_koni');

        $routes = [
            'dashboard.admin-koni',
            'admin.cabor.index',
            'admin.atlet.index',
            'admin.pengguna.index',
            'admin.agenda.index',
            'admin.persuratan.index',
            'admin.templates.index',
            'dashboard.admin-cabor',
        ];

        foreach ($routes as $routeName) {
            $response = $this
                ->actingAs($staff)
                ->get(route($routeName));

            $response->assertForbidden();
        }
    }

    /**
     * Role selain Staff tidak boleh membuka panel Staff.
     */
    public function test_other_roles_cannot_access_staff_pages(): void
    {
        $roles = [
            'admin_koni',
            'ketua_koni',
            'sekretaris_koni',
            'admin_cabor',
            'atlet',
            'pelatih',
            'atlet_pelatih',
        ];

        foreach ($roles as $role) {
            $user = $this->createUserWithRole($role);

            $this->actingAs($user)
                ->get(route('dashboard.staff-koni'))
                ->assertForbidden();

            $this->actingAs($user)
                ->get(route('staff.cabor.index'))
                ->assertForbidden();

            $this->actingAs($user)
                ->get(route('staff.agenda.index'))
                ->assertForbidden();

            $this->actingAs($user)
                ->get(route('staff.surat.index'))
                ->assertForbidden();

            $this->actingAs($user)
                ->get(route('staff.templates.index'))
                ->assertForbidden();

            $this->actingAs($user)
                ->get(route('staff.publikasi.index'))
                ->assertForbidden();
        }
    }

    /**
     * Data master Staff tetap read-only. Agenda, persuratan, template surat, dan publikasi
     * dapat dikelola Staff. Untuk inventaris, Staff hanya boleh menjalankan tiga transaksi
     * pada aset pusat: mutasi lokasi, peminjaman, dan pengembalian.
     */
    public function test_staff_routes_do_not_allow_unapproved_write_methods(): void
    {
        $writeMethods = [
            'POST',
            'PUT',
            'PATCH',
            'DELETE',
        ];

        $allowedStaffWriteRoutes = [
            // Transaksi inventaris pusat yang memang menjadi kewenangan Staff.
            'staff.inventaris.mutasi' => ['POST'],
            'staff.inventaris.peminjaman.store' => ['POST'],
            'staff.inventaris.peminjaman.return' => ['POST'],

            // Staff boleh membuat dan menutup sesi absensi yang dikelolanya.
            'staff.absensi.store' => ['POST'],
            'staff.absensi.close' => ['POST'],
        ];

        $allRoutes = collect(Route::getRoutes()->getRoutes());

        $staffRoutes = $allRoutes->filter(function ($route) use ($allowedStaffWriteRoutes) {
            return str_starts_with(
                $route->uri(),
                'staff/'
            )
                && !str_starts_with($route->uri(), 'staff/agenda')
                && !str_starts_with($route->uri(), 'staff/surat')
                && !str_starts_with($route->uri(), 'staff/templates-surat')
                && !str_starts_with($route->uri(), 'staff/publikasi')
                && !array_key_exists($route->getName(), $allowedStaffWriteRoutes);
        });

        $this->assertNotEmpty($staffRoutes);

        foreach ($staffRoutes as $route) {
            $methods = array_intersect(
                $route->methods(),
                $writeMethods
            );

            $this->assertEmpty(
                $methods,
                'Ditemukan route perubahan data Staff yang tidak diizinkan: '
                . $route->uri()
            );
        }

        // Pastikan pengecualian transaksi Staff hanya berlaku pada endpoint
        // inventaris dan absensi yang secara eksplisit disetujui di atas.
        $routesByName = $allRoutes->keyBy(fn ($route) => $route->getName());

        foreach ($allowedStaffWriteRoutes as $routeName => $expectedMethods) {
            $this->assertTrue(
                $routesByName->has($routeName),
                'Route transaksi Staff tidak ditemukan: '.$routeName
            );

            $actualWriteMethods = array_values(array_intersect(
                $routesByName->get($routeName)->methods(),
                $writeMethods
            ));

            $this->assertSame(
                $expectedMethods,
                $actualWriteMethods,
                'Metode HTTP route Staff tidak sesuai: '.$routeName
            );
        }
    }

    /**
     * Parameter pencarian dan filter berbentuk array ditolak.
     */
    public function test_staff_rejects_array_query_parameters(): void
    {
        $staff = $this->createUserWithRole('staff_koni');

        $this->actingAs($staff)
            ->get(route('staff.cabor.index', [
                'q' => ['invalid'],
            ]))
            ->assertStatus(422);

        $this->actingAs($staff)
            ->get(route('staff.atlet.index', [
                'cabor_id' => ['invalid'],
            ]))
            ->assertStatus(422);
    }
}
