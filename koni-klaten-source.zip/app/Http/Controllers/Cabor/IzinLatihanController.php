<?php

namespace App\Http\Controllers\Cabor;

use App\Http\Controllers\Controller;
use App\Models\IzinLatihan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class IzinLatihanController extends Controller
{
    private function caborId(Request $request): int
    {
        $id = $request->user()->cabang_olahraga_id;
        abort_unless($id, 403, 'Akun Admin Cabor belum terhubung dengan cabang olahraga.');

        return (int) $id;
    }

    public function index(Request $request): View
    {
        $items = IzinLatihan::query()
            ->where('cabang_olahraga_id', $this->caborId($request))
            ->with('user')
            ->latest()
            ->paginate(15);

        return view('cabor.izin-latihan.index', [
            'items' => $items,
            'cabor' => $request->user()->cabangOlahraga,
        ]);
    }

    public function download(Request $request, IzinLatihan $izinLatihan): StreamedResponse
    {
        $owned = IzinLatihan::query()
            ->where('cabang_olahraga_id', $this->caborId($request))
            ->findOrFail($izinLatihan->id);
        abort_unless(Storage::disk('local')->exists($owned->file_path), 404);

        return Storage::disk('local')->download($owned->file_path, $owned->file_original_name);
    }
}
