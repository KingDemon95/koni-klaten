@extends('layouts.cabor')
@section('title', 'Dokumen Izin Latihan')
@section('heading', 'Izin Latihan')
@section('content')
<div class="space-y-5">
    <section class="rounded-2xl bg-gradient-to-r from-[#171717] to-[#3b1015] p-6 text-white"><p class="text-xs font-bold tracking-widest text-yellow-300">ADMIN CABANG OLAHRAGA</p><h2 class="mt-2 text-2xl font-black">Dokumen Izin Latihan</h2><p class="mt-1 text-sm text-gray-200">Dokumen dari Atlet dan Pelatih pada cabang olahraga Anda.</p></section>
    <section class="space-y-3">
        @forelse($items as $item)
            <article class="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-gray-200 bg-white p-4">
                <div><h3 class="font-black">{{ $item->nama_pemohon }}</h3><p class="mt-1 text-xs text-gray-500">{{ ucfirst($item->jenis_pemohon) }} · {{ $item->tujuan }}</p><p class="mt-1 text-sm text-gray-600">{{ $item->tanggal_mulai?->format('d/m/Y') }} @if($item->tanggal_selesai)– {{ $item->tanggal_selesai->format('d/m/Y') }} @endif</p><p class="mt-1 text-xs text-gray-500">{{ $item->keperluan }}</p></div>
                <div class="flex items-center gap-2"><span class="rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-800">{{ ucfirst($item->status) }}</span><a href="{{ route('cabor.izin-latihan.download', $item) }}" class="rounded-lg bg-gray-900 px-3 py-2 text-xs font-bold text-white">Unduh Dokumen</a></div>
            </article>
        @empty
            <div class="rounded-xl border border-dashed border-gray-300 bg-white p-8 text-center text-sm text-gray-500">Belum ada dokumen izin latihan yang dikirim dari cabor ini.</div>
        @endforelse
        <div>{{ $items->links() }}</div>
    </section>
</div>
@endsection
