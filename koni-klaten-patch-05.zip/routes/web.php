<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Cabor\CaborPanelController;
use App\Http\Controllers\Staff\StaffPanelController;
use App\Http\Controllers\Atlet\AtletPanelController;
use App\Http\Controllers\Pelatih\PelatihPanelController;
use App\Http\Controllers\PublicPortalController;
use App\Http\Controllers\PublicAgendaController;
use App\Http\Controllers\AgendaController;
use App\Http\Controllers\SuratController;
use App\Http\Controllers\TemplateSuratController;
use App\Http\Controllers\Portal\PrestasiController as PortalPrestasiController;
use App\Http\Controllers\Cabor\PrestasiController as CaborPrestasiController;
use App\Http\Controllers\Portal\IzinLatihanController;
use App\Http\Controllers\Cabor\IzinLatihanController as CaborIzinLatihanController;

Route::get('/', [PublicPortalController::class, 'home'])->name('public.home');
Route::get('/cabang-olahraga', [PublicPortalController::class, 'caborIndex'])->name('public.cabor.index');
Route::get('/cabang-olahraga/{cabangOlahraga}', [PublicPortalController::class, 'caborShow'])
    ->whereNumber('cabangOlahraga')
    ->name('public.cabor.show');
Route::get('/struktur-pengurus', [PublicPortalController::class, 'strukturIndex'])->name('public.struktur.index');
Route::get('/agenda', [PublicAgendaController::class, 'index'])->name('public.agenda.index');
Route::get('/agenda/{agenda:slug}', [PublicAgendaController::class, 'show'])->name('public.agenda.show');

Route::middleware('auth')->group(function () {

    // Pengalihan dashboard berdasarkan role.
    Route::get('/dashboard', function () {

        $user = auth()->user();

        if ($user->hasRole('admin_koni')) {
            return redirect()->route('dashboard.admin-koni');
        }

        if ($user->hasRole('staff_koni')) {
            return redirect()->route('dashboard.staff-koni');
        }

        if ($user->hasRole('admin_cabor')) {
            return redirect()->route('dashboard.admin-cabor');
        }

        if ($user->hasRole('atlet')) {
            return redirect()->route('dashboard.atlet');
        }

        if ($user->hasRole('pelatih')) {
            return redirect()->route('dashboard.pelatih');
        }

        if ($user->hasRole('atlet_pelatih')) {
            return redirect()->route('dashboard.atlet-pelatih');
        }

        abort(403, 'Akun belum memiliki role yang sesuai.');

    })->name('dashboard');

    // Dashboard Admin KONI
    Route::view('/dashboard/admin-koni', 'admin.dashboard')
        ->middleware('role:admin_koni')
        ->name('dashboard.admin-koni');


    // Dashboard Staff KONI
    Route::get(
        '/dashboard/staff-koni',
        [StaffPanelController::class, 'dashboard']
    )
        ->middleware('role:staff_koni')
        ->name('dashboard.staff-koni');


    // Dashboard Admin Cabor
    Route::get(
        '/dashboard/admin-cabor',
        [CaborPanelController::class, 'dashboard']
    )
        ->middleware([
            'role:admin_cabor',
            'milik_cabor',
        ])
        ->name('dashboard.admin-cabor');

    // Dashboard Atlet dan Pelatih
    Route::view('/dashboard/atlet-pelatih', 'dashboard.index')
        ->middleware('role:atlet_pelatih')
        ->name('dashboard.atlet-pelatih');

    
    // Dashboard Atlet
    Route::get(
        '/dashboard/atlet',
        [AtletPanelController::class, 'dashboard']
    )
        ->middleware('role:atlet')
        ->name('dashboard.atlet');

    // Dashboard Pelatih 
    Route::get(
        '/dashboard/pelatih',
        [PelatihPanelController::class, 'dashboard']
    )
        ->middleware('role:pelatih')
        ->name('dashboard.pelatih');

});


Route::middleware(['auth', 'role:admin_koni'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {

    Route::resource(
        'cabor',
        \App\Http\Controllers\Admin\CabangOlahragaController::class
    )->except(['show']);


    Route::resource(
        'atlet',
        \App\Http\Controllers\Admin\AtletController::class
    )->except(['show']);

    Route::resource(
        'pelatih',
        \App\Http\Controllers\Admin\PelatihController::class
    )->except(['show']);

    Route::resource(
        'struktur-organisasi',
        \App\Http\Controllers\Admin\StrukturOrganisasiController::class
    )->except(['show']);

    Route::post('agenda/{agenda}/publish', [AgendaController::class, 'publish'])->name('agenda.publish');
    Route::post('agenda/{agenda}/revisi', [AgendaController::class, 'requestRevision'])->name('agenda.revisi');
    Route::resource('agenda', AgendaController::class)->except(['show']);


    // Nama dan URL Persuratan Admin KONI dibuat eksplisit agar konsisten dengan menu panel.
    Route::get('persuratan', [SuratController::class, 'index'])->name('persuratan.index');
    Route::get('persuratan/{surat}', [SuratController::class, 'show'])->name('persuratan.show');
    Route::post('persuratan/{surat}/keputusan', [SuratController::class, 'decide'])->name('persuratan.keputusan');
    Route::get('persuratan/{surat}/file/{jenis}', [SuratController::class, 'download'])->name('persuratan.file');

    // Alias URL lama dipertahankan agar tautan yang sudah pernah digunakan tidak langsung rusak.
    Route::get('surat', [SuratController::class, 'index'])->name('surat.index');
    Route::get('surat/{surat}', [SuratController::class, 'show'])->name('surat.show');
    Route::post('surat/{surat}/keputusan', [SuratController::class, 'decide'])->name('surat.keputusan');
    Route::get('surat/{surat}/file/{jenis}', [SuratController::class, 'download'])->name('surat.file');

    Route::get('templates-surat', [TemplateSuratController::class, 'index'])->name('templates.index');
    Route::post('templates-surat', [TemplateSuratController::class, 'store'])->name('templates.store');
    Route::put('templates-surat/{template}', [TemplateSuratController::class, 'update'])->name('templates.update');
    Route::delete('templates-surat/{template}', [TemplateSuratController::class, 'destroy'])->name('templates.destroy');
    Route::get('templates-surat/{template}/download', [TemplateSuratController::class, 'download'])->name('templates.download');


    Route::view('/publikasi', 'admin.pages.placeholder', [
        'pageTitle' => 'Publikasi dan Berita',
        'pageDescription' => 'Pengelolaan berita, dokumentasi, foto, dan informasi kegiatan KONI.',
    ])->name('publikasi.index');


    Route::resource(
        'pengguna',
        \App\Http\Controllers\Admin\PenggunaController::class
    )->except(['show']);


    Route::view('/pengaturan', 'admin.pages.placeholder', [
        'pageTitle' => 'Pengaturan Sistem',
        'pageDescription' => 'Pengaturan identitas organisasi dan konfigurasi aplikasi.',
    ])->name('settings');

});

Route::middleware([
        'auth',
        'role:admin_cabor',
        'milik_cabor',
    ])
    ->prefix('cabor')
    ->name('cabor.')
    ->group(function () {

    Route::get(
        '/atlet',
        [CaborPanelController::class, 'atlet']
    )->name('atlet.index');

    Route::get(
        '/pelatih',
        [CaborPanelController::class, 'pelatih']
    )->name('pelatih.index');

    Route::get(
        '/pengurus',
        [\App\Http\Controllers\Cabor\PengurusController::class, 'index']
    )->name('pengurus.index');

    Route::resource(
        'atlet',
        \App\Http\Controllers\Cabor\AtletController::class
    )->except(['index', 'show']);

    Route::resource(
        'pelatih',
        \App\Http\Controllers\Cabor\PelatihController::class
    )->except(['index', 'show']);
   
    Route::resource(
        'pengurus',
        \App\Http\Controllers\Cabor\PengurusController::class
    )
        ->except(['index', 'show'])
        ->parameters([
            'pengurus' => 'pengurus',
        ]);

    Route::post('agenda/{agenda}/ajukan', [AgendaController::class, 'submit'])->name('agenda.submit');
    Route::resource('agenda', AgendaController::class)->except(['show']);

    Route::resource('surat', SuratController::class)->only(['index', 'create', 'store', 'show', 'edit', 'update', 'destroy']);
    Route::post('surat/{surat}/ajukan', [SuratController::class, 'submit'])->name('surat.submit');
    Route::get('surat/{surat}/file/{jenis}', [SuratController::class, 'download'])->name('surat.file');

    Route::get('templates-surat', [TemplateSuratController::class, 'index'])->name('templates.index');
    Route::get('templates-surat/{template}/download', [TemplateSuratController::class, 'download'])->name('templates.download');

    Route::get('prestasi', [CaborPrestasiController::class, 'index'])->name('prestasi.index');
    Route::post('prestasi/{prestasi}/review', [CaborPrestasiController::class, 'review'])->name('prestasi.review');
    Route::get('prestasi/{prestasi}/bukti', [CaborPrestasiController::class, 'download'])->name('prestasi.bukti');

    Route::get('izin-latihan', [CaborIzinLatihanController::class, 'index'])->name('izin-latihan.index');
    Route::get('izin-latihan/{izinLatihan}/download', [CaborIzinLatihanController::class, 'download'])->name('izin-latihan.download');

});

Route::middleware([
        'auth',
        'role:staff_koni',
    ])
    ->prefix('staff')
    ->name('staff.')
    ->group(function () {

    Route::get(
        '/cabor',
        [StaffPanelController::class, 'cabor']
    )->name('cabor.index');

    Route::get(
        '/atlet',
        [StaffPanelController::class, 'atlet']
    )->name('atlet.index');

    Route::get(
        '/pelatih',
        [StaffPanelController::class, 'pelatih']
    )->name('pelatih.index');

    Route::get(
        '/pengurus',
        [StaffPanelController::class, 'pengurus']
    )->name('pengurus.index');

    Route::post('agenda/{agenda}/publish', [AgendaController::class, 'publish'])->name('agenda.publish');
    Route::post('agenda/{agenda}/revisi', [AgendaController::class, 'requestRevision'])->name('agenda.revisi');
    Route::resource('agenda', AgendaController::class)->except(['show']);

    Route::get('surat', [SuratController::class, 'index'])->name('surat.index');
    Route::get('surat/{surat}', [SuratController::class, 'show'])->name('surat.show');
    Route::post('surat/{surat}/revisi', [SuratController::class, 'requestRevision'])->name('surat.revisi');
    Route::post('surat/{surat}/teruskan', [SuratController::class, 'forward'])->name('surat.teruskan');
    Route::post('surat/{surat}/sampaikan', [SuratController::class, 'deliver'])->name('surat.sampaikan');
    Route::get('surat/{surat}/file/{jenis}', [SuratController::class, 'download'])->name('surat.file');

    Route::get('templates-surat', [TemplateSuratController::class, 'index'])->name('templates.index');
    Route::post('templates-surat', [TemplateSuratController::class, 'store'])->name('templates.store');
    Route::put('templates-surat/{template}', [TemplateSuratController::class, 'update'])->name('templates.update');
    Route::delete('templates-surat/{template}', [TemplateSuratController::class, 'destroy'])->name('templates.destroy');
    Route::get('templates-surat/{template}/download', [TemplateSuratController::class, 'download'])->name('templates.download');

});

Route::middleware([
        'auth',
        'role:atlet',
    ])
    ->prefix('atlet')
    ->name('atlet.')
    ->group(function () {

    Route::get('/profil', [AtletPanelController::class, 'profil'])->name('profil');
    Route::get('/profil/edit', [AtletPanelController::class, 'editProfil'])->name('profil.edit');
    Route::put('/profil', [AtletPanelController::class, 'updateProfil'])->name('profil.update');

    Route::resource('prestasi', PortalPrestasiController::class)->except(['show']);
    Route::get('prestasi/{prestasi}/bukti', [PortalPrestasiController::class, 'download'])->name('prestasi.bukti');

    Route::get('izin-latihan', [IzinLatihanController::class, 'index'])->name('izin-latihan.index');
    Route::post('izin-latihan', [IzinLatihanController::class, 'store'])->name('izin-latihan.store');
    Route::get('izin-latihan/{izinLatihan}/download', [IzinLatihanController::class, 'download'])->name('izin-latihan.download');
    Route::delete('izin-latihan/{izinLatihan}', [IzinLatihanController::class, 'destroy'])->name('izin-latihan.destroy');

    Route::get('templates-surat', [TemplateSuratController::class, 'index'])->name('templates.index');
    Route::get('templates-surat/{template}/download', [TemplateSuratController::class, 'download'])->name('templates.download');

});

Route::middleware([
        'auth',
        'role:pelatih',
    ])
    ->prefix('pelatih')
    ->name('pelatih.')
    ->group(function () {

    Route::get('/profil', [PelatihPanelController::class, 'profil'])->name('profil');
    Route::get('/profil/edit', [PelatihPanelController::class, 'editProfil'])->name('profil.edit');
    Route::put('/profil', [PelatihPanelController::class, 'updateProfil'])->name('profil.update');

    Route::resource('prestasi', PortalPrestasiController::class)->except(['show']);
    Route::get('prestasi/{prestasi}/bukti', [PortalPrestasiController::class, 'download'])->name('prestasi.bukti');

    Route::get('izin-latihan', [IzinLatihanController::class, 'index'])->name('izin-latihan.index');
    Route::post('izin-latihan', [IzinLatihanController::class, 'store'])->name('izin-latihan.store');
    Route::get('izin-latihan/{izinLatihan}/download', [IzinLatihanController::class, 'download'])->name('izin-latihan.download');
    Route::delete('izin-latihan/{izinLatihan}', [IzinLatihanController::class, 'destroy'])->name('izin-latihan.destroy');

    Route::get('templates-surat', [TemplateSuratController::class, 'index'])->name('templates.index');
    Route::get('templates-surat/{template}/download', [TemplateSuratController::class, 'download'])->name('templates.download');

});
